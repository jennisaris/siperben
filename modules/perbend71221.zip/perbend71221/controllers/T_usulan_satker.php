<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* Namespace alias. */
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//require_once 'T_usulan_daftar.php';
class T_usulan_satker extends MX_Controller {
  var $prefix = 'app';
  var $ar_statusid = array();
  var $ar_statusperubahan = array();

  var $ar_unor = array();
	public function __construct() {
		parent::__construct();
		$controller = "perbend/t_usulan_satker";
		$table  = $this->prefix."_t_usulan";

   		$this->_setTitle('Usulan Satker');
		$this->_setController($controller);
		$this->_init('default');

		$this->_addTable($table);
		$this->_addField($table, 'id', '', true, true);
		$this->_addField($table, 'ijns', 'ijns', false, true);
		$this->_addField($table, 'iunorid', 'Satuan Kerja', true);
		$this->_addField($table, 'cnousul', 'Nomor Usul', true);
		$this->_addField($table, 'dtglusul', 'Tanggal Usul', true);
		$this->_addField($table, 'istatusid', 'Status Perubahan', true);
		$this->_addField($table, 'ijnsprubhnid', 'Jenis Perubahan', true);
		$this->_addField($table, 'lampiran2', 'Lampiran Surat Usulan (Hasil Generate)', false, false, true);
		$this->_addField($table, 'lampiran', 'Lampiran Surat Usulan (Sudah di TTD & dlm format PDF)', false, false, true);
		$this->_addField($table, 'tfile', 'Lampiran', false, true);
		$this->_addField($table, 'vtype', 'Tipe Dokumen', false, true);
		$this->_addField($table, 'nsize', 'nsize', false, true);
		$this->_addField($table, 'istatus', 'Status Usulan', false, true);
		$this->_addField($table, 'keterangan', 'Keterangan', false, true, true);
		$this->_addField($table, 'daftarnama', '', false, false, true, 0, 'left', '','', true);
		$this->_addField($table, 'tcreated', 'Waktu dibuat', false, true);
		$this->_addField($table, 'ccreatedby', 'Dibuat oleh', false, true);
		$this->_addField($table, 'tupdated', 'Waktu ubah', false, true);
		$this->_addField($table, 'cupdatedby', 'Diubah oleh', false, true);
		$this->_addField($table, 'ctahun', 'Tahun', false, true);
		$this->_addField($table, 'itipe', 'itipe', false, true);
		$this->_addField($table, 'issinde', 'issinde', false, true);
		$this->_addField($table, 'tfile2', 'Lampiran', false, true);
		$this->_addField($table, 'vtype2', 'Tipe Dokumen', false, true);
		$this->_addField($table, 'nsize2', 'nsize', false, true);

		//$this->_add2SearchField($table, 'cnip');
		//$this->_add2SearchField($table, 'vname');
		//$this->_add2SearchField($table, 'ldeleted');
		
		$rows = $this->getall('', $this->prefix.'_m_status', '*', array('ldeleted'=>0));
		foreach($rows as $r) {
		$this->ar_statusid[$r->id] = $r->vdesc;
		}
		
		$this->_changeType($table, 'istatusid', 'combobox', 
		$this->ar_statusid);
		
		$rows = $this->getall('', $this->prefix.'_m_perubahan', '*', array('ldeleted'=>0));
		foreach($rows as $r) {
		$this->ar_statusperubahan[$r->id] = $r->vdesc;
		}
		
		$this->_changeType($table, 'ijnsprubhnid', 'combobox', 
		$this->ar_statusperubahan);
		
		$this->_changeType($table, 'istatus', 'combobox', 
		$this->session->sysparam->status_usulan);
		
		$this->_changeType($table, 'dtglusul', 'date', 'd-m-Y');
		
		$this->_add2SearchField($table, 'cnousul');
		$this->_add2SearchField($table, 'dtglusul');
		$this->_add2SearchField($table, 'istatusid');
		$this->_add2SearchField($table, 'ijnsprubhnid');
		
		$this->_setAlign($table, 'dtglusul', 'center');
		$this->_setAlign($table, 'istatus', 'center');
		$this->_setAlign($table, 'istatusid', 'center');
		$this->_setAlign($table, 'ijnsprubhnid', 'center');
    
		$this->_add2ListField($table, 'iunorid, cnousul, dtglusul, istatusid, ijnsprubhnid, tfile, istatus, keterangan');//, tupdated, cupdatedby');

		/*
		if ( $this->session->superuser != 1 ) {
		  $kd_satker = $this->session->orgs;
		  $kd_satker = "'".implode("','", $kd_satker)."'";
			$this->_addQuery($table, $table.'.iunorid in ('.$kd_satker.')', 'and', '', true);
			//$this->_addQuery($table, $table.'.iunorid = '.trim($this->session->username), 'and', '', true);
		}
		*/

		//if ( !in_array($this->session->groupid, explode(",", $this->session->sysparam->all_group[0])) ) {
		if ( !$this->session->isadmin ) {			
			$this->_addQuery($table, $table.'.iunorid = '.trim($this->session->username), 'and', '', true);
		} else {
		  $groupids = explode(',', $this->session->groupid);

		  //print_r($this->session->sysparam->group_superuser[0]);
		  $all_groups = explode(",", $this->session->sysparam->all_group[0]);
		  //print_r($groupids);
		  //exit;
			//if ( in_array($this->session->sysparam->group_superuser[0], $groupids) ) {
			$ada = 0;
			foreach($groupids as $g) {
				if (in_array($g, $all_groups)) $ada++;
			}

			if ( $ada > 0 ) {
				$ar_unor = array();
				foreach($this->getall('', 'app_m_unor', 'kode, nama') as $r) {
					$ar_unor[$r->kode] = $r->nama; 
				}
			} else {
				$ar_unor = $this->session->orgs;
			}

			foreach($ar_unor as $k=>$v) {
				$ar_unor_[] = $k; 
			}
			
			$this->_changeType($table, 'iunorid', 'combobox', $ar_unor);
			$this->_add2SearchField($table, 'iunorid');

			$ar_unor_ = "'".implode("','", $ar_unor_)."'";
			$this->_addQuery($table, $table.".iunorid in ({$ar_unor_})", "and", "", true);
		}

		$this->_addQuery($table, 'app_t_usulan.ijns = 1', 'and', '', true);
		$this->_addQuery($table, "app_t_usulan.ctahun = '{$this->session->settahun}'", 'and', '', true);
		
		$this->_addOrderBy($table, ['tcreated'=>'asc']);

		//clear session header_controller
		$this->session->unset_userdata('header_controller');
		
		
		//print_r($this->session->sysparam);
		//print_r($this->session->sysparam->group_verifikator[0]);
		//echo 'test : '.$this->session->sysparam->group_verifikator[0]->msg;
		//exit;
		
		//print_r($this->session->sysparam);
		//exit;
		  //$groupid = $this->session->sysparam->group_verifikator[0]->id;
    		//$sql = "SELECT email from priv_t_user where igroupid like '%{$groupid}%'";
    		//echo $sql;
    		//$tos = $this->db->query($sql)->result();
  		//print_r($tos);
  		//exit;
  		//print_r($this->session->groupid);
  		//echo '<br/>';
  		//print_r($this->session->sysparam->all_group[0]);
  		/*
  		$groupsid = explode(',', $this->session->groupid);
  		//echo 'sizeOf : '.sizeOf(explode(',', $this->session->groupid));
  		foreach($groupsid as $g) {
  		  echo $g.'<br/>';
    		if ( !in_array($g, explode(",", $this->session->sysparam->all_group[0])) ) {
    		  echo 'gak ada<br/>';
    		} else {
    		  echo 'ada <br/>';
    		}
  		}
  		exit;
  		*/
  }
	
	function searchBox_app_t_usulan_cnousul($name) {
	  $value = (isset($_GET['q']) ? $_GET['q'] : '');
	  $input = "<input type='text' name='{$name}' class='form-control {$name}' id='{$name}' value='{$value}'/>";

		return $input;
	}
	
	function insertBox_app_t_usulan_ctahun($name) {
		$input = "<input type='hidden' name='{$name}' class='form-control {$name}' id='{$name}' value='{$this->session->settahun}'/>";

		return $input;
	}
	
	function listBox_app_t_usulan_tupdated($value, $datas) {
	  if ( $value != null ) {
	    return date('d-m-Y H:i:s', strtotime($value));
	  } else return date('d-m-Y H:i:s', strtotime($datas->app_t_usulan_tcreated));
	}
	
	function listBox_app_t_usulan_cupdatedby($value, $datas) {
	  if ( $value != null ) {
	    $nama = $this->getrow($this->db, 'priv_t_user', 'realname', array('username'=>trim($value)))->realname;
	   } else {
	     $nama = $this->getrow($this->db, 'priv_t_user', 'realname', array('username'=>trim($datas->app_t_usulan_ccreatedby)))->realname;
	   }
	  
	  return $nama;
	}

	function insertBox_app_t_usulan_iunorid($name) {
	  
	    $groupids = explode(',', $this->session->groupid);
			$ada = 0;
			if (sizeOf($groupids) > 0 ) {
  			foreach($groupids as $g) {
  			  //echo $g.',';
    			if ( in_array($g, explode(",", $this->session->sysparam->all_group[0])) ) $ada++;
  			}
			} else {
			  if ( in_array($this->session->groupid, explode(",", $this->session->sysparam->all_group[0])) ) $ada++;
			}
		if ( $ada == 0 ) {
			$name_txt = $this->getrow('', 'app_m_unor', 'nama', array('kode'=>trim($this->session->username)))->nama;
			$input = "<input type='hidden' name='{$name}' id='{$name}' class='form-control {$name}' value='{$this->session->username}'/>";
			$input .= "<input readonly type='text' name='{$name}_txt' id='{$name}' class='form-control {$name}' value='{$name_txt}'/>";
		} else {

			$input = "<input type='hidden' name='{$name}' id='{$name}' class='form-control {$name}' value=''/>";
			$input .= "<input placeholder='Satuan Kerja' type='text' name='{$name}_txt' id='{$name}_txt' class='form-control {$name}_txt' value=''/>"; 
		}

		return $input;
	}

	function updateBox_app_t_usulan_iunorid($name, $value) {
		$name_txt = $this->getrow('', 'app_m_unor', 'nama', array('kode'=>$value))->nama;
		if ($name_txt == '' ) $name_txt = $value;
		
		  $groupids = explode(',', $this->session->groupid);
			$ada = 0;
			if (sizeOf($groupids) > 0 ) {
  			foreach($groupids as $g) {
  			  //echo $g.',';
    			if ( in_array($g, explode(",", $this->session->sysparam->all_group[0])) ) $ada++;
  			}
			} else {
			  if ( in_array($this->session->groupid, explode(",", $this->session->sysparam->all_group[0])) ) $ada++;
			}
		if ( $ada == 0 ) {
			
			$input = "<input type='hidden' name='{$name}' id='{$name}' class='form-control {$name}' value='{$this->session->username}'/>";
			$input .= "<input readonly type='text' name='{$name}_txt' id='{$name}_txt' class='form-control {$name}_txt' value='{$name_txt}'/>";
		} else {

			$input = "<input type='hidden' name='{$name}' id='{$name}' class='form-control {$name}' value='{$value}'/>";
			$input .= "<input readonly placeholder='Satuan Kerja' type='text' name='{$name}_txt' id='{$name}_txt' class='form-control {$name}_txt' value='{$name_txt}'/>"; 
		}

		return $input;
	}

	function viewBox_app_t_usulan_iunorid($name, $value) {
		$name_txt = $this->getrow('', 'app_m_unor', 'nama', array('kode'=>$value))->nama." (".$value.") ";
		if ($name_txt == '' ) $name_txt = $value;
		$html = "<p class='form-control-static {$name}'>".$name_txt."</p>";
		return $html;
	}

	function listBox_app_t_usulan_iunorid($value) {
		$name_txt = $this->getrow('', 'app_m_unor', 'nama', array('kode'=>$value))->nama. " (".$value.")";
		if ($name_txt == '' ) $name_txt = $value;
		return $name_txt;
	}

	public function after_insert_processor($id, $post) {
		$new_post = array();
		$new_post['tcreated']   = date('Y-m-d H:i:s');
		$new_post['ccreatedby'] = $this->session->userdata['username'];

		$this->db->where('id', $id);
		$this->db->update($this->prefix.'_t_usulan', $new_post);

		//
		//app_t_usulan_istatusid
		//app_t_usulan_ijnsprubhnid
		//print_r($post);
		//exit;
		if ( ( 
			(int)$post->app_t_usulan_istatusid == 1 && (int)$post->app_t_usulan_ijnsprubhnid == 1 ) 
			||
			((int)$post->app_t_usulan_istatusid == 2 && (int)$post->app_t_usulan_ijnsprubhnid == 9 ) ) {
			//karena tetap, langsung copy sj untuk pegawainya dr request di tahun sebelumnya
			$sql = "INSERT INTO app_t_usulan_pegawai 
					(ifrom, iusulanid, ispelatihan, cnip, vname, cnosertifikat, cgolid, 
					vgolnm, vpktnm, cjabid, vjabnm, ijabid2, istatus, valasan, 
					istatus2, valasan2, cnosk, inoskid, ckduker, 
					tcreated, ccreatedby, tupdated, cupdatedby, itipe, isnonaktif, 
					cnipold, itolak) 
					SELECT ifrom, {$id} as iusulanid, ispelatihan, cnip, vname, cnosertifikat, cgolid, 
					vgolnm, vpktnm, cjabid, vjabnm, ijabid2, istatus, valasan, 
					istatus2, valasan2, cnosk, inoskid, ckduker, 
					tcreated, ccreatedby, tupdated, cupdatedby, itipe, isnonaktif, 
					cnipold, itolak FROM app_t_usulan_pegawai 
					WHERE ckduker = '{$post->app_t_usulan_iunorid}' AND ijabid2 IN (1,2,3) AND isnonaktif = '0' 
					and iusulanid != {$id}";

			$this->db->query($sql);

			//update
			$sql = "UPDATE app_t_usulan_pegawai SET 
					isnonaktif = 1, 
					tupdated = '".date('Y-m-d H:i:s')."', 
					cupdatedby = '".trim($this->session->username)."' 
					WHERE ckduker = '{$post->app_t_usulan_iunorid}' AND ijabid2 IN (1,2,3) AND isnonaktif = '0' 
					and iusulanid != {$id} ";

			$this->db->query($sql);	
		}
	}

	public function after_update_processor($id, $post, $oldpost) {
		
		
		if ($post->app_t_usulan_istatus == 1) {

			if ( (int)$post->app_t_usulan_istatusid == 1 && (int)$post->app_t_usulan_ijnsprubhnid == 1 ) {
				$new_post = array();
				$new_post['istatus'] = 7;
				$new_post['tupdated']   = date('Y-m-d H:i:s');
				$new_post['cupdatedby'] = $this->session->userdata['username'];

				$this->db->where('id', $id);
				$this->db->update($this->prefix.'_t_usulan', $new_post);

			} else {

				$new_post = array();
				$new_post['tupdated']   = date('Y-m-d H:i:s');
				$new_post['cupdatedby'] = $this->session->userdata['username'];

				$this->db->where('id', $id);
				$this->db->update($this->prefix.'_t_usulan', $new_post);
				
				$post->app_t_usulan_id = $id;
				//print_r($post);exit;
				//send_email ke next step
				$this->send_email(0, '', '', $post, TRUE);
				
				//send_email ke requestor
				$tos = [
				0=>(object)['unorid'=>$post->app_t_usulan_iunorid, 'email'=>$this->getrow('', 'priv_t_user', 'email', ['username'=>trim($post->app_t_usulan_iunorid)])->email]
				];
				//print_r($tos);
				//exit;
				$tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[99]->url."?q=".$post->app_t_usulan_cnousul."'>disini</a>";
					
				$tahap = $this->session->sysparam->status_usulan[1];
				$pesan = str_replace("__tautan__", $tautan, $this->session->sysparam->group_verifikator[99]->msg);
				$pesan = str_replace("__tahap__", $tahap, $pesan);
				$this->send_email(99, $tos, $pesan, $post);
			}
		} else {
			/*$sql = "SELECT 
						b.cnip as nip_new,
						b.vname as nama_new,
						c.cgelardepan as gelardepan_new,
						c.cgelarbelakang as gelarbelakang_new,
						(select concat(pangkat, ', ', nama) 
						from kepeg_m_golongan where id = b.cgolid) as pangkat_new,
						(select nama from kepeg_m_jabatan where kode = b.cjabid) as jabatan_new,
						(select vname from app_m_jabatan where id = b.ijabid2) as jabatan2_new, 
						b.cnipold as nip_old,
						(select vname from kepeg_m_pegawai where cnip = b.cnipold) as nama_old,
						(select cgelardepan from kepeg_m_pegawai where cnip = b.cnipold) as cgelardepan_old,
						(select cgelarbelakang from kepeg_m_pegawai where cnip = b.cnipold) ascgelarbelakang_old,
						(select concat(pangkat, ', ', nama) 
									from kepeg_m_golongan where id = 
						(select cgolid from kepeg_m_pegawai where cnip = b.cnipold)) as pangkat_old,
						(select nama from kepeg_m_jabatan where kode = (select cjabid from kepeg_m_pegawai where cnip = b.cnipold)) as jabatan_old,
						(select vname from app_m_jabatan where id = (select ijabid2 from kepeg_m_pegawai where cnip = b.cnipold)) as jabatan2_old
					FROM app_t_usulan_pegawai b, kepeg_m_pegawai c 
					where b.cnip = c.cnip and b.iusulanid = {$id}";

			//echo $sql;exit;
			$rowsP = $this->db->query($sql)->result();

			$norut = 1;
			foreach($rowsP as $r) {
				//buat data array
				$gelardpn = $r->gelardepan_new != NULL ? $r->gelardepan_new.' ' : '';
				$gelarblk = $r->gelarbelakang_new != NULL ? ', '.$r->gelarbelakang_new : '';
				$nama_dgn_gelar = $gelardpn.''.ucwords(strtolower($r->nama_new)).''.$gelarblk;

				$gelardpn_old = $r->cgelardepan_old != NULL ? $r->cgelardepan_old.' ' : '';
				$gelarblk_old = $r->ascgelarbelakang_old != NULL ? ', '.$r->ascgelarbelakang_old : '';
				$nama_dgn_gelar_old = $gelardpn_old.''.ucwords(strtolower($r->nama_old)).''.$gelarblk_old;

				$datas = [
					'norut' => $norut, 
					'jenisjabatan' => $r->jabatan2_new,
						'uraian_nama' => [
							'namaold' => $nama_dgn_gelar_old, 
							'namanew' => $nama_dgn_gelar
						],
						'uraian_nip' => [
							'nipold' => $r->nip_old, 
							'nipnew' => $r->nip_new 
						],
						'uraian_pangkat' => [
							'pangkatold' => $r->pangkat_old, 
							'pangkatnew' => $r->pangkat_new
						],
						'uraian_jabatan' => [
							'jabatanold' => (
								trim($r->jabatan2_old) != trim($this->session->sysparam->beda_jabatan[0]) ? 
								trim($r->jabatan2_old) : trim($r->jabatan_old)
							),
							'jabatannew' => (
								trim($r->jabatan2_new) != trim($this->session->sysparam->beda_jabatan[0]) ? 
								trim($r->jabatan2_new) : trim($r->jabatan_new)
							)
						]
				];
				
	
				$norut++;
	
				$datas2['block'][] = $datas;
			}

			//get isplt, nama, nip
			//$ttd = $this->getrow('', 'app_m_ttd', 'isplt, cnip, vname', array('id'=>$ttdid));
			$nip_pejabat_ttd  = $this->getrow('', 'kepeg_m_unor', 'cnippimpinan', ['kode_satker'=>$post->app_t_usulan_iunorid, 'date_expired'=>NULL])->cnippimpinan;
			$nama_pejabat_ttd = ucwords(strtolower($this->getrow('', 'kepeg_m_pegawai', 'vname', ['cnip'=>$nip_pejabat_ttd])->vname));

			//
			$kode_unor = $post->app_t_usulan_iunorid;
			$nama_unor = $this->getrow('', 'app_m_unor', 'nama', ['kode'=>$post->app_t_usulan_iunorid])->nama;
			

			$datas2['datanya'] = [
									'ta' => $this->session->settahun,
									'no_surat'=> trim($post->app_t_usulan_cnousul),
									'tgl_bln_thn'=>(!empty($post->app_t_usulan_dtglusul) ? $this->nama_bulan_indonesia(date('d-m-Y', strtotime($post->app_t_usulan_dtglusul))) : ''),
									'kode_unor'=>$kode_unor,
									'unit_kerja'=>ucwords(strtolower($nama_unor)),
									'nama_pejabat_ttd'=>$nama_pejabat_ttd,
									'nip_pejabat_ttd'=>$nip_pejabat_ttd
								];

			//function create_sk_from_template($post=null, $datas=null, $template='sk.docx') {
			$tfiles = $this->create_surat_from_template($datas2, trim($this->session->sysparam->template_surat_usulan[0]));

			$new_post = array();
			$new_post['tfile2'] = $tfiles['file1'];
			$new_post['tfile3'] = $tfiles['file2'];
			$new_post['tupdated']   = date('Y-m-d H:i:s');
			$new_post['cupdatedby'] = $this->session->userdata['username'];

			$this->db->where('id', $id);
			$this->db->update($this->prefix.'_t_usulan', $new_post);*/

			$new_post = array();
			$new_post['tupdated']   = date('Y-m-d H:i:s');
			$new_post['cupdatedby'] = $this->session->userdata['username'];

			$this->db->where('id', $id);
			$this->db->update($this->prefix.'_t_usulan', $new_post);
		}
	}

	function nama_bulan_indonesia($date, $pemisah=' ') {

		$tgl = date('d', strtotime($date));
		$bln = date('m', strtotime($date));
		$thn = date('Y', strtotime($date));

		$ar_bulan_indonesia = [
			'01' => 'Januari',
			'02' => 'Februari',
			'03' => 'Maret',
			'04' => 'April',
			'05' => 'Mei',
			'06' => 'Juni',
			'07' => 'Juli',
			'08' => 'Agustus',
			'09' => 'September',
			'10' => 'Oktober',
			'11' => 'November',
			'12' => 'Desember'
		];

		return $tgl.$pemisah.$ar_bulan_indonesia[$bln].$pemisah.$thn;
	}

	function listBox_app_t_usulan_keterangan($value, $datas) {
		$pesan = '';
		$sql = "SELECT count(*) as total from app_t_usulan_pegawai where iusulanid = {$datas->app_t_usulan_id} and 
				case
					when istatus2 != 0 then istatus2
					else istatus
				end = 2 and ispelatihan=0";
		$total = $this->db->query($sql)->row()->total;
		if ( $total > 0 ) {
			$pesan = " Ada {$total} penolakan ";
		} else $pesan = "";

		return $pesan;
	}
	
	function listBox_ACTION($buttons, $datas) {
		//unset($buttons['hapus']);

		if ( $datas->app_t_usulan_istatus != 5) {
			if ( $datas->app_t_usulan_itipe == 0 ) {
				$sql = "SELECT count(*) as total from app_t_usulan_pegawai where iusulanid = {$datas->app_t_usulan_id} and 
						case
						when istatus2 != 0 then istatus2
						else istatus
						end = 2 and ispelatihan=0";
				$total = $this->db->query($sql)->row()->total;
		
			if ( $total > 0 || 
				//trim($datas->app_t_usulan_ccreatedby) != trim($this->session->username)
				( trim($datas->app_t_usulan_ccreatedby) != trim($this->session->username) 
					&& trim($datas->app_t_usulan_iunorid) != trim($this->session->username))
			) {
					unset($buttons['ubah']);
					if ( !$this->session->superuser ) unset($buttons['hapus']);
				} else {
					if ( $datas->app_t_usulan_istatus > 0 ) unset($buttons['ubah']);
				}
			} else {
				//if ( !$this->session->superuser ) unset($buttons['ubah']);
				$groupids = explode(',', $this->session->groupid);
				$ada = 0;
				if (sizeOf($groupids) > 0 ) {
					foreach($groupids as $g) {
						//echo $g.',';
						if ( in_array($g, explode(",", $this->session->sysparam->all_group[0])) ) $ada++;
					}
				} else {
				if ( in_array($this->session->groupid, explode(",", $this->session->sysparam->all_group[0])) ) $ada++;
				}
				if ( $ada == 0 ) { unset($buttons['ubah']);
				} else { 
					if ( !$this->session->superuser ) unset($buttons['hapus']);
				}
			}
		} else {
			unset($buttons['hapus']);
		}
	  
	  	return $buttons;
	}
	
	function listBox_app_t_usulan_tfile($value, $datas) {
	  $input = "";
	  
	  $vtype = trim($datas->app_t_usulan_vtype);
	  $tfile = $value;
	  
	  if ( !empty($value) ){
			$input .= "<span data-toggle='modal' data-target='#myPreview_{$datas->app_t_usulan_id}' style='cursor:pointer;' class='label label-primary'>
						<b>Surat Usulan Sudah di TTD</b>
					  </span>";
  	  $input .= "<div class='modal fade' id='myPreview_{$datas->app_t_usulan_id}' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
  				   <div class='modal-dialog' role='document' style='width:65%;'>
  					 <div class='modal-content'>
  					   <div class='modal-header'>
  						 <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
  						 <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Surat Usulan {$datas->app_t_usulan_cnousul}</h4>
  					   </div>
  					   <div class='modal-body' id='modal-body'>
  						 <div class='form-group'>
  							 <div id='html_telusuri'>";
  
  		if ( $vtype != 'application/pdf' ) {
  			$height='100';$width='';
  		} else { $height='100%';$width='700';}
  
  		$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";
  
  
  		$input .= "			 </div>
  						 </div>
  					   </div>
  					</div>
  				</div>
  			</div>";
	  }
	  
		return $input;
	}

	public function viewBox_app_t_usulan_lampiran2($name, $value, $datas) {
		$input = "<div>";
		//if ( $this->getrow('', 'app_t_usulan_pegawai', 'count(*) as total', ['iusulanid'=>$datas->app_t_usulan_id])->total > 0 ) {
		//if ( !empty($datas->app_t_usulan_tfile2) ) {
			$input .= "<button type='button' onclick='unduhfile({$datas->app_t_usulan_id}, 2);' class='btn btn-success'>
						<i class='fas fa-download'></i> Unduh Surat Usulan
					  </button>";
		//} else {
		//	$input .= "<span>-</span>";
		//}

		$input .= "</div>";
		return $input;
	}

	public function updateBox_app_t_usulan_lampiran2($name, $value, $datas) {
		$input = "<div>";
		//if ( !empty($datas->app_t_usulan_tfile2) ) {
		//if ( $this->getrow('', 'app_t_usulan_pegawai', 'count(*) as total', ['iusulanid'=>$datas->app_t_usulan_id])->total > 0 ) {
			$input .= "<button type='button' onclick='unduhfile({$datas->app_t_usulan_id}, 2);' class='btn btn-success'>
						<i class='fas fa-download'></i> Unduh Surat Usulan
					  </button>";
		//} else {
		//	$input .= "<span>-</span>";
		//}

		$input .= "</div>";
		return $input;
	}

	public function insertBox_app_t_usulan_lampiran2($name) {
		/* $input = "<input type='file' name='{$name}' id='{$name}' class='form-control {$name}' accept='application/pdf'/>";
		$input .= $this->session->sysparam->info_max_upload[0];
		$input .= "<br/><span id='lbl_surat_usulan' data-toggle='modal' data-target='#myPreview' style='cursor:pointer;display:none;' class='label label-primary'>
					<b>Surat Usulan</b>
					</span>";

		$input .= "<div class='modal fade' id='myPreview' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
				   <div class='modal-dialog' role='document' style='width:65%;'>
					 <div class='modal-content'>
					   <div class='modal-header'>
						 <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
						 <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Surat Usulan </h4>
					   </div>
					   <div class='modal-body' id='modal-body'>
						 <div class='form-group'>
							 <div id='html_telusuri'>";

		$height='100%';$width='700';
		$vtype = 'application/pdf';
		$tfile = "";

		$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";


		$input .= "			 </div>
						 </div>
					   </div>
					</div>
				</div>
			</div>"; */

		$input = "<p class='form-control-static {$name}'>-</p>";

		
		return $input;
	}

	public function insertBox_app_t_usulan_lampiran($name) {
		/* $input = "<input type='file' name='{$name}' id='{$name}' class='form-control {$name}' accept='application/pdf'/>";
		$input .= $this->session->sysparam->info_max_upload[0];
		$input .= "<br/><span id='lbl_surat_usulan' data-toggle='modal' data-target='#myPreview' style='cursor:pointer;display:none;' class='label label-primary'>
					<b>Surat Usulan</b>
					</span>";

		$input .= "<div class='modal fade' id='myPreview' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
				   <div class='modal-dialog' role='document' style='width:65%;'>
					 <div class='modal-content'>
					   <div class='modal-header'>
						 <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
						 <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Surat Usulan </h4>
					   </div>
					   <div class='modal-body' id='modal-body'>
						 <div class='form-group'>
							 <div id='html_telusuri'>";

		$height='100%';$width='700';
		$vtype = 'application/pdf';
		$tfile = "";

		$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";


		$input .= "			 </div>
						 </div>
					   </div>
					</div>
				</div>
			</div>"; */

		$input = "<p class='form-control-static {$name}'>-</p>";

		
		return $input;
	}
	

	public function updateBox_app_t_usulan_lampiran($name, $value, $datas) {
		$tfile = $datas->app_t_usulan_tfile;
		$vtype = trim($datas->app_t_usulan_vtype);

		//if ( $this->getrow('', 'app_t_usulan_pegawai', 'count(*) as total', ['iusulanid'=>$datas->app_t_usulan_id])->total > 0  && $datas->app_t_usulan_tfile2 != NULL ) {
		if ( $datas->app_t_usulan_tfile2 != NULL ) {			

			$input = "<input type='file' name='{$name}' id='{$name}' class='form-control {$name}' accept='application/pdf'/>";
			$input .= $this->session->sysparam->info_max_upload[0];
			if ( !empty($tfile) ){
				$input .= "<br/><span id='lbl_surat_usulan' data-toggle='modal' data-target='#myPreview' style='cursor:pointer;' class='label label-primary'>
							<b>Surat Usulan</b>
						</span>";
			}

			$input .= "<div class='modal fade' id='myPreview' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
					<div class='modal-dialog' role='document' style='width:65%;'>
						<div class='modal-content'>
						<div class='modal-header'>
							<button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
							<h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Surat Usulan {$datas->app_t_usulan_cnousul} </h4>
						</div>
						<div class='modal-body' id='modal-body'>
							<div class='form-group'>
								<div id='html_telusuri'>";

			if (trim($vtype) != 'application/pdf' ) {
				$height='100';$width='';
			} else { $height='100%';$width='700';}

			$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";


			$input .= "			 </div>
							</div>
						</div>
						</div>
					</div>
				</div>";
		} else {
			$input = "<p class='form-control-static {$name}'>-</p>";
		}

		
		return $input;
	}

	public function viewBox_app_t_usulan_lampiran($name, $value, $datas) {
		$tfile = $datas->app_t_usulan_tfile;
		$vtype = trim($datas->app_t_usulan_vtype);

		$input = "";
		if ( $datas->app_t_usulan_tfile2 != NULL ) {
			if ( !empty($tfile) ){
				$input .= "<br/><span data-toggle='modal' data-target='#myPreview' style='cursor:pointer;' class='label label-primary'>
							<b>Surat Usulan</b>
						</span>";

				$input .= "<div class='modal fade' id='myPreview' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
						<div class='modal-dialog' role='document' style='width:65%;'>
						  <div class='modal-content'>
							<div class='modal-header'>
							  <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
							  <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Preview </h4>
							</div>
							<div class='modal-body' id='modal-body'>
							  <div class='form-group'>
								  <div id='html_telusuri'>";
	 
				if (trim($vtype) != 'application/pdf' ) {
					$height='100';$width='';
				} else { $height='100%';$width='700';}
	 
				$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";
		
		
				$input .= "			 </div>
								</div>
								</div>
							</div>
						</div>
					</div>";
			}
		} else {
			$input = "<p class='form-control-static {$name}'>-</p>";
		}

		
		return $input;
	}
	
	public function before_insert_processor($post) {
		$post->app_t_usulan_ijns = 1;
		if ( $post->app_t_usulan_issinde == 0 ) {
			$files = $this->uploadfiles($_FILES['app_t_usulan_lampiran']);
			if ( !empty($files->file) ) {
				$post->app_t_usulan_tfile = $files->file;
				$post->app_t_usulan_vtype = $files->type;
				$post->app_t_usulan_nsize = $files->size;
			}
		}
		return $post;
	}
	
	public function before_update_processor($id, $post) {
		if ( $post->app_t_usulan_issinde == 0 ) {
			$files = $this->uploadfiles($_FILES['app_t_usulan_lampiran']);
			if ( !empty($files->file) ) {
				$post->app_t_usulan_tfile = $files->file;
				$post->app_t_usulan_vtype = $files->type;
				$post->app_t_usulan_nsize = $files->size;
			}
		}
	
		return $post;
	}
	
	function insertCheck_app_t_usulan_ijnsprubhnid($value, $post) {
	  $data['status'] = true;

	  if ( ($post->app_t_usulan_istatusid == 1 && $value != 1) 
	    ||
	    ($post->app_t_usulan_istatusid > 1 && $value == 1 )
	    ) {
	     $data['status']  = false;
    	 $data['msg'] = 'Jenis perubahan tidak sesuai. Periksa kembali isian anda';
    	 $data['obj'] = 'app_t_usulan_ijnsprubhnid';
	   } 
	   return $data;
  }
  
  function updateCheck_app_t_usulan_ijnsprubhnid($value, $post, $id) {
    $data['status'] = true;
	  if ( ($post->app_t_usulan_istatusid == 1 && $value != 1) 
	    ||
	    ($post->app_t_usulan_istatusid > 1 && $value == 1 )
	    ) {
	     $data['status']  = false;
    	 $data['msg'] = 'Jenis perubahan tidak sesuai. Periksa kembali isian anda';
    	 $data['obj'] = 'app_t_usulan_ijnsprubhnid';
	   } 
	   return $data;
  }
  
	function insertCheck_app_t_usulan_iunorid($value, $post) {
		$data['status'] = true;
		if ( !empty($value) ) {
		  //total request
		  $sql = "SELECT count(*) as total from app_t_usulan a
					    WHERE a.iunorid = {$value} and a.itipe=0 
					    and a.ctahun ='{$this->session->settahun}' 
					    and a.istatusid={$post->app_t_usulan_istatusid} 
						and a.ijnsprubhnid = '{$post->app_t_usulan_ijnsprubhnid}' 
						and a.istatus = 7";
			$total_request = $this->db->query($sql)->row()->total;
			
			if ($total_request > 0) {
    			$sql = "SELECT count(*) as total from app_t_usulan a, 
    					app_t_usulan_pegawai b  
    					WHERE a.id = b.iusulanid and 
    					a.iunorid = {$value} and b.istatus2 = 2 
    					and a.itipe = 0 and ctahun='{$this->session->settahun}' 
						and a.istatusid={$post->app_t_usulan_istatusid} 
						and a.ijnsprubhnid = '{$post->app_t_usulan_ijnsprubhnid}' 
						and a.istatus != 7";
    			//echo $sql;exit;
    			$total = $this->db->query($sql)->row()->total;
    			if ( $total == 0 ) {
    				$data['status']  = false;
    				$data['msg'] = 'Ada pengajuan usulan yang belum selesai. Selalu cek progress pengajuan usulan anda. Terima kasih';
    				$data['obj'] = 'app_t_usulan_iunorid';
    			}
			}
		}

		return $data;
	}

	function updateCheck_app_t_usulan_iunorid($value, $post, $id) {
		$data['status'] = true;
		if ($this->input->post('app_t_usulan_istatus') == 1) {
			//print_r($post);
			//echo $value;
			//exit;

			if ( !empty($post->app_t_usulan_tfile) ) {
				if ($this->gettotaldaftarpegawai($id) == 0) {	
					$data['status']  = false;
					$data['msg'] = 'Lengkapi daftar pegawai yang diusulkan';
				} else {
					$sql = "SELECT cjabid2 from app_m_perubahan 
						where id = {$post->app_t_usulan_ijnsprubhnid}";
				
				
					if ($this->db->query($sql)->row()->cjabid2 != null ) {
						
						$cjabid2 = explode(',', $this->db->query($sql)->row()->cjabid2);
						
						$ijabid2 = array();
						$sql = "SELECT ijabid2 from app_t_usulan_pegawai
								where iusulanid = {$id}";
						foreach($this->db->query($sql)->result() as $r) {
							$ijabid2[] = $r->ijabid2;
						}
						
						//print_r($cjabid2);
						//print_r($ijabid2);
						//print_r(array_diff($cjabid2, $ijabid2));
						//echo 'test : '.sizeOf(array_diff($cjabid2, $ijabid2));
						//exit;
						if (sizeOf(array_diff($cjabid2, $ijabid2)) > 0 ) {
							$data['status']  = false;
							$data['msg'] = 'Jumlah daftar pegawai yang diusulkan tidak sesuai dgn jumlah jabatan yang wajib diisi';
						}
					}
				}
			} else {
				if ( empty(trim($post->app_t_usulan_cnousul)) ) {
					$data['status']  = false;
					$data['msg'] = 'Lengkapi Kolom No. Usul ';
					$data['obj'] = 'app_t_usulan_cnousul';
				} else if (empty(trim($post->app_t_usulan_dtglusul))) {
					$data['status']  = false;
					$data['msg'] = 'Lengkapi Kolom Tgl. Usul ';
					$data['obj'] = 'app_t_usulan_dtglusul';
				} else {
					$data['status']  = false;
					$data['msg'] = 'Lengkapi Lampiran Surat Usulan (Sudah di TTD & dlm format PDF) ';
					$data['obj'] = 'app_t_usulan_lampiran';
				}
			}	
	  	} 
		return $data;
	}
	
	/* function insertCheck_app_t_usulan_tfile($value, $post) {
		
		$data['status'] = true;
		if ( $post->app_t_usulan_issinde == 0 ) {
			if ( !empty($value) ) {
					if ( trim($post->app_t_usulan_vtype) != 'application/pdf' ) {
						$data['status']  = false;
						$data['msg'] = 'Lampiran wajib dalam format PDF';
						$data['obj'] = 'app_t_usulan_lampiran';
					} else if ( $post->app_t_usulan_nsize > (int)$this->session->sysparam->max_size_upload[0] ) {
						$data['status']  = false;
						$data['msg'] = str_replace('__upload__', 'Lampiran Surat Usulan (dlm format PDF)', $this->session->msg_max_size_upload_tercapai[0]);
						$data['obj'] = 'app_t_usulan_lampiran';
					}
			}
		}

		return $data;
	}
	
	function updateCheck_app_t_usulan_tfile($value, $post, $id) {
		
		$data['status']  = true;
	  	if ($this->input->post('app_t_usulan_istatus') == 1) {
			print_r($post);
			echo $value;
			exit;

  			if ($this->gettotaldaftarpegawai($id) == 0) {	
  				$data['status']  = false;
  				$data['msg'] = 'Lengkapi daftar pegawai yang diusulkan';
  			} else {
  			 	$sql = "SELECT cjabid2 from app_m_perubahan 
  			          where id = {$post->app_t_usulan_ijnsprubhnid}";
  			  
  			  
				if ($this->db->query($sql)->row()->cjabid2 != null ) {
					
					$cjabid2 = explode(',', $this->db->query($sql)->row()->cjabid2);
					
					$ijabid2 = array();
					$sql = "SELECT ijabid2 from app_t_usulan_pegawai
							where iusulanid = {$id}";
					foreach($this->db->query($sql)->result() as $r) {
						$ijabid2[] = $r->ijabid2;
					}
					
					//print_r($cjabid2);
					//print_r($ijabid2);
					//print_r(array_diff($cjabid2, $ijabid2));
					//echo 'test : '.sizeOf(array_diff($cjabid2, $ijabid2));
					//exit;
					if (sizeOf(array_diff($cjabid2, $ijabid2)) > 0 ) {
						$data['status']  = false;
						$data['msg'] = 'Jumlah daftar pegawai yang diusulkan tidak sesuai dgn jumlah jabatan yang wajib diisi';
					}
				}
  			}

			if ( empty($value)) {
				$data['status']  = false;
				$data['msg'] = 'Lengkapi Lampiran Surat Usulan (Sudah di TTD & dlm format PDF) ';
			}
  			//echo 'test';
  			//exit;
  			return $data;
	  	} else return $this->insertCheck_app_t_usulan_tfile($value, $post);
	} */
	
	public function manipulate_update_button($buttons, $datas) {
	  if (!$datas->app_t_usulan_itipe) {
		  
		$btn_simpan = "<button type='submit' id='btn_save' class='btn btn-primary' style='{$style}' 
  								onclick='tinyMCE.triggerSave(true,true);$(\"#t_usulan_satker_form-edit #app_t_usulan_istatus\").val(0);'>
  										<i class='fa fa-save'></i>&nbsp;Simpan {$this->title}
  									</button>";	
		$btn_simpankirim = "<button type='submit' id='btn_send' class='btn btn-primary' style='{$style}' 
  								onclick='tinyMCE.triggerSave(true,true);$(\"#t_usulan_satker_form-edit #app_t_usulan_istatus\").val(1);'>
  										<i class='glyphicon glyphicon-send'></i>&nbsp;Simpan & Kirim {$this->title}
  									</button>";
  
  		$buttons['simpan'] = $btn_simpan.' '.$btn_simpankirim;
	  }
		//array_push($buttons, $btn_simpankirim);

		return $buttons;
	}
	
	function gettotaldaftarpegawai($iusulanid) {
		return $this->getrow('', 'app_t_usulan_pegawai', 'count(*) as total', array('iusulanid'=>$iusulanid, 'ispelatihan'=>0))->total;
	}
	
	function after_delete_processor($id) {
		$where = array('iusulanid'=>$id);
		$this->db->where($where);
		$this->db->delete('t_usulan_pegawai');
	}
	
	public function insertBox_app_t_usulan_daftarnama($name) {
		return "<p class='form-control-static {$name}'></p>";
	}

	public function updateBox_app_t_usulan_daftarnama($name, $value, $datas) {
		$html = "<div>
				<ul class='nav nav-tabs' role='tablist' id='all_tabs'>
				  <li role='presentation' class='active'>
					  <a href='#tab1' data-toggle='tab' aria-controls='tab1' role='tab'>Daftar Pegawai</a>
				  </li>
				</ul>
			  
				<div class='tab-content'>
				  <div role='tabpanel' class='tab-pane fade in active' id='tab1'></div>
				</div>
			  </div>";
			  
	  	$html .= "<script type='text/javascript'>
				  $(document).ready(function() {
					  //tab 1
					  //alert($('.app_t_usulan_id').val());
					  url = '".base_url()."perbend/t_usulan_daftar/index';
					  $('#tab1').html(getHTML(url, '', 0, false));
					  $('#t_usulan_daftar #q_app_t_usulan_pegawai_iusulanid').val($('.app_t_usulan_id').val());
					  $('#t_usulan_daftar #q_app_t_usulan_pegawai_ispelatihan').val(0);
				  });
				  
				</script>";				
			  
	  return $html;	
	}

	public function viewBox_app_t_usulan_daftarnama($name, $value, $datas) {
		$html = "<div>
				<ul class='nav nav-tabs' role='tablist' id='all_tabs'>
				  <li role='presentation' class='active'>
					  <a href='#tab1' data-toggle='tab' aria-controls='tab1' role='tab'>Daftar Pegawai</a>
				  </li>
				</ul>
			  
				<div class='tab-content'>
				  <div role='tabpanel' class='tab-pane fade in active' id='tab1'></div>
				</div>
			  </div>";
			  
	  	$html .= "<script type='text/javascript'>
				  $(document).ready(function() {
					  //tab 1
					  url = '".base_url()."perbend/t_usulan_daftar/index';
					  $('#tab1').html(getHTML(url, '', 0, false));
					  $('#t_usulan_daftar #q_app_t_usulan_pegawai_iusulanid').val($('.app_t_usulan_id').val());
					  $('#t_usulan_daftar #q_app_t_usulan_pegawai_ispelatihan').val(0);
				  });
				  
				</script>";				
			  
	  return $html;	
	}

	public function manipulate_url_save($save) {
		unset($save);
		$save['method'] = "save_usulan('".base_url()."perbend/t_usulan_satker', 't_usulan_satker', '', '', 'form-modal')";
		return $save;
	}

	function app_t_usulan_output() {
		$js = "<script type='text/javascript'>
				$(document).ready(function() {
					$('#app_t_usulan_iunorid_txt').keyup(function() {
						$('#app_t_usulan_iunorid').val('');
					});

					$('#app_t_usulan_cnousul').keyup(function() {
						$('#lbl_surat_usulan').hide();
						$('#myPreview #html_telusuri').html('');
						$('#app_t_usulan_issinde').val(0);

						$('#app_t_usulan_dtglusul').val('');
						$('#app_t_usulan_tfile').val('');
					});

					$('#app_t_usulan_iunorid_txt').typeahead({
						source: function (query, result) {
							$.ajax({
								url: '".base_url()."perbend/m_unor/getunor',
								data: 'query='+query,
								dataType: 'json',
								type: 'POST',
								beforeSend: function() {
									// alert('sending data');
									// do some loading options
									btn_save_html = $('.btn_save').html();
									if ( isloading==true ) $('#divLoading').addClass('show');
									if ( !debug ) {
										$('button').attr('disabled', true);
										$('.btn_save').html(\"<i class='fas fa-cog fa-spin'> </i> Mohon Tunggu...\");
									}
								},
								success: function (data) {
									result($.map(data, function (item) {
										return item;
									}));
								}
							});
						},
						items: 20,
						updater: function (item) {
							$('#app_t_usulan_iunorid').val(item.kode);

							$(\"#divLoading\").removeClass('show');
							$('button').removeAttr('disabled');
							$('.btn_save').html(\"<i class='fa fa-save' aria-hidden='true'> </i> Simpan {$this->title}\");

							return  item.value;
						},
					});
				});

				function save_usulan(url, table_id, default_txt_confirm='Simpan {$this->title}. Anda yakin?', _ismodal=false, _modals='form-modal') {
				
					if ( default_txt_confirm == '' ) default_txt_confirm='Simpan {$this->title}. Anda yakin?';
					if ( $('#t_usulan_satker_form-edit #app_t_usulan_istatus').val() == 1 ) default_txt_confirm='Simpan dan Kirim {$this->title}. Anda yakin?';
					var form_name = table_id+'_form-edit';
					var formData = new FormData(jQuery('#'+form_name)[0]);
					save_confirm(url+'/save', formData, default_txt_confirm, table_id, _ismodal, function(output) {
						var o = jQuery.parseJSON(output);
						$('div').removeClass('has-error');
						if ( o.status == true ) {
							if ( $('#'+table_id+'_form-edit #app_t_usulan_istatus').val() == 1 ) { 
								$('#'+table_id+'-panel-default-form').hide(); 
							} else edit(url+'/edit/'+o.id, table_id, _ismodal, _modals);

							if ( $('#t_usulan_satker_form-edit #app_t_usulan_istatus').val() == 1 ) 
							  setTimeout(location.reload(true), 2000);
							else reload_grid(url+'/lists', table_id, '', table_id+'-panel-default-form');
							
						} else {
							if ( o.msg != undefined) bootbox_alert('', '', o.msg, false, false);
							$('.'+o.obj).focus();
							$('div .grp_'+o.obj).addClass('has-error');
							$('div .div_'+o.obj).addClass('has-error');
							if ( _ismodal ) $('#'+_modals).css('overflow', 'scroll');
							return false;
						}
					});
					$('body').css('padding-right', 0);
				}

				function get_detail_surat_sinde() {
					var nosurat = $('#app_t_usulan_cnousul').val();
					
					if ( nosurat != '' ) {
						var kriteria = 'nosurat='+nosurat;
						var o = jQuery.parseJSON(getHTML3('".base_url()."perbend/t_usulan_satker/get_detail_surat_sinde', kriteria));

						if ( o.nosurat != null ) {

							$('#app_t_usulan_dtglusul').val(o.tglsurat);
							$('#app_t_usulan_tfile').val(o.isifile);

							var str_embed = \"<embed src='data:application/pdf;base64,\"+o.isifile+\"' type='application/pdf' width='100%' height='700' alt='application/pdf'>\"; 
							$('#lbl_surat_usulan').show();
							$('#myPreview #html_telusuri').html(str_embed);
							$('#app_t_usulan_issinde').val(1);
							$('#app_t_usulan_vtype').val('application/pdf');

							bootbox_alert('', '', 'Detail surat '+nosurat+' berhasil diambil', true);
						} else {
							bootbox_alert('', '', 'Detail surat '+nosurat+' gagal diambil', true, false);
						}

					} else {
						$('#app_t_usulan_issinde').val(0);
						bootbox_alert('', '', 'Lengkapi No. Usul Surat', true, false);
						$('#app_t_usulan_cnousul').select();
						$('div .grp_app_t_usulan_cnousul').addClass('has-error');
						$('div .div_app_t_usulan_cnousul').addClass('has-error');

						return false;
					}	
				}

				function unduhfile(id) {
					window.open('".base_url()."perbend/t_usulan_satker/unduhfile/'+id, '_unduh_');
					setTimeout(
						edit('".base_url()."perbend/t_usulan_satker/edit/'+id, 't_usulan_satker', false, 'form-modal'), 
					3000);
				}

				</script>";

		return $js;
	}

	function unduhfile($a) {
		$this->generate($a);
		$files = $this->getrow($this->dbpeng, 'app_t_usulan', 'tfile2', array('id'=>$a));
		$bfile = $files->tfile2;
		$nama = "Surat_Usulan_{$a}.docx";

		$decoded = base64_decode($bfile);
		header("Content-Disposition: attachment;filename={$nama}");
		header("Content-Type: application/force-download");
		echo $decoded;
	}

	function generate($id) {

		//get unorid = 
		$usulans = $this->getrow($this->dbpeng, 'app_t_usulan', 'iunorid, cnousul, dtglusul', array('id'=>$id));
		$sql = "SELECT 
						b.cnip as nip_new,
						c.vname as nama_new,
						c.cgelardepan as gelardepan_new,
						c.cgelarbelakang as gelarbelakang_new,
						(select concat(pangkat, ', ', nama) 
						from kepeg_m_golongan where id = b.cgolid) as pangkat_new,
						(select nama from kepeg_m_jabatan where kode = b.cjabid) as jabatan_new,
						(select vname from app_m_jabatan where id = b.ijabid2) as jabatan2_new, 
						b.cnipold as nip_old,
						(select vname from kepeg_m_pegawai where cnip = b.cnipold) as nama_old,
						(select cgelardepan from kepeg_m_pegawai where cnip = b.cnipold) as cgelardepan_old,
						(select cgelarbelakang from kepeg_m_pegawai where cnip = b.cnipold) ascgelarbelakang_old,
						(select concat(pangkat, ', ', nama) 
									from kepeg_m_golongan where id = 
						(select cgolid from kepeg_m_pegawai where cnip = b.cnipold)) as pangkat_old,
						(select nama from kepeg_m_jabatan where kode = (select cjabid from kepeg_m_pegawai where cnip = b.cnipold)) as jabatan_old,
						(select vname from app_m_jabatan where id = (select ijabid2 from kepeg_m_pegawai where cnip = b.cnipold)) as jabatan2_old,
						b.isbrubah 
					FROM app_t_usulan_pegawai b, kepeg_m_pegawai c 
					where b.cnip = c.cnip and b.iusulanid = {$id}";

			//echo $sql;exit;
			$rowsP = $this->db->query($sql)->result();

			$norut = 1;
			foreach($rowsP as $r) {
				//buat data array
				$gelardpn = $r->gelardepan_new != NULL ? $r->gelardepan_new.' ' : '';
				$gelarblk = $r->gelarbelakang_new != NULL ? ', '.$r->gelarbelakang_new : '';
				$nama_dgn_gelar = $gelardpn.''.ucwords(strtolower($r->nama_new)).''.$gelarblk;

				$gelardpn_old = $r->cgelardepan_old != NULL ? $r->cgelardepan_old.' ' : '';
				$gelarblk_old = $r->ascgelarbelakang_old != NULL ? ', '.$r->ascgelarbelakang_old : '';
				$nama_dgn_gelar_old = $gelardpn_old.''.ucwords(strtolower($r->nama_old)).''.$gelarblk_old;

				

				$datas = [
					'norut' => $norut, 
					'jenisjabatan' => $r->jabatan2_new,
						'uraian_nama' => [
							'namaold' => $nama_dgn_gelar_old, 
							'namanew' => $nama_dgn_gelar
						],
						'uraian_nip' => [
							'nipold' => $r->nip_old, 
							'nipnew' => $r->nip_new 
						],
						'uraian_pangkat' => [
							'pangkatold' => $r->pangkat_old, 
							'pangkatnew' => $r->pangkat_new
						],
						'uraian_jabatan' => [
							'jabatanold' => (
								trim($r->jabatan2_old) != trim($this->session->sysparam->beda_jabatan[0]) ? 
								trim($r->jabatan2_old) : trim($r->jabatan_old)
							),
							'jabatannew' => (
								trim($r->jabatan2_new) != trim($this->session->sysparam->beda_jabatan[0]) ? 
								trim($r->jabatan2_new) : trim($r->jabatan_new)
							)
						],
						'perubahan' => $r->isbrubah
				];
				
	
				$norut++;
	
				$datas2['block'][] = $datas;
			}

			//get isplt, nama, nip
			//$ttd = $this->getrow('', 'app_m_ttd', 'isplt, cnip, vname', array('id'=>$ttdid));
			$nip_pejabat_ttd  = $this->getrow('', 'kepeg_m_unor', 'cnippimpinan', ['kode_satker'=>$usulans->iunorid, 'date_expired'=>NULL])->cnippimpinan;
			$nama_pejabat_ttd = ucwords(strtolower($this->getrow('', 'kepeg_m_pegawai', 'vname', ['cnip'=>$nip_pejabat_ttd])->vname));
			$jabatan_satker_ttd = ucwords(strtolower($this->session->sysparam->jabatan_pimpinan[$this->getrow('', 'kepeg_m_unor', 'ijabpimpinan', ['kode_satker'=>$usulans->iunorid])->ijabpimpinan]));

			//
			$kode_unor = $usulans->iunorid;
			$nama_unor = $this->getrow('', 'app_m_unor', 'nama', ['kode'=>$usulans->iunorid])->nama;
			

			$datas2['datanya'] = [
									'ta' => $this->session->settahun,
									'no_surat'=> (!empty(trim($usulans->cnousul)) ? trim($usulans->cnousul) : '-'),
									'tgl_bln_thn'=>(!empty($usulans->dtglusul) ? $this->nama_bulan_indonesia(date('d-m-Y', strtotime($usulans->dtglusul))) : '-'),
									'kode_unor'=>$kode_unor,
									'unit_kerja'=>ucwords(strtolower($nama_unor)),
									'jabatan_nama_satker'=>$jabatan_satker_ttd.' '.ucwords(strtolower($nama_unor)),
									'nama_pejabat_ttd'=>$nama_pejabat_ttd,
									'nip_pejabat_ttd'=>$nip_pejabat_ttd
								];

			//function create_sk_from_template($post=null, $datas=null, $template='sk.docx') {
			$tfiles = $this->create_surat_from_template($datas2, trim($this->session->sysparam->template_surat_usulan[0]));

			$new_post = array();
			$new_post['tfile2'] = $tfiles['file1'];
			$new_post['tfile3'] = $tfiles['file2'];
			$new_post['tupdated']   = date('Y-m-d H:i:s');
			$new_post['cupdatedby'] = $this->session->userdata['username'];

			$this->db->where('id', $id);
			$this->db->update($this->prefix.'_t_usulan', $new_post);
	}
  
  function send_email($next=0, $tos='', $pesan='', $post, $isnotif=FALSE) {
  		if ($tos=='') {
  		  $groupid = $this->session->sysparam->group_verifikator[$next]->id;
    		$sql = "SELECT email, username from priv_t_user where igroupid like '%{$groupid}%'";
    		//echo $sql;
    		$tos = $this->db->query($sql)->result();
  		}
  		
  		if ($isnotif==TRUE) {
          $pesan = $this->session->sysparam->group_verifikator[$next]->desc;
          $tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[$next]->url."'>{$pesan}</a>";
          $notifs=[
                //'username'=>$t2->username,
                'url'=>base_url().$this->session->sysparam->group_verifikator[$next]->url,
                'usulanid'=>$post->app_t_usulan_id,
                'groupid'=>$groupid,
                'msg' => $pesan,
                'created'=> date('Y-m-d H:i:s'),
                'createdby'=>trim($this->session->username)
              ];
          $this->db->insert('app_notification', $notifs);
          /*$sql = $this->db->set($notifs)->get_compiled_insert('app_notification');
          echo $sql;exit;*/
      }
  		
  		//PHPMailer
  	  $mail = new PHPMailer(true);
  	  //print_r($mail);
  	  //exit;
  	  
  	  /*echo $this->session->sysparam->smtphost[0];
  	  echo $this->session->sysparam->smtpauth[0];
  	  echo $this->session->sysparam->smtpsecure[0];
  	  echo $this->session->sysparam->smtpuser[0];
  	  echo $this->session->sysparam->smtppasswd[0];
  	  echo $this->session->sysparam->smtpport[0];
  	  exit;*/
  	  
  	  /* Open the try/catch block. */
      try {
         /* SMTP parameters. */
         $mail->isSMTP();
         $mail->Host = $this->session->sysparam->smtphost[0];
         $mail->SMTPAuth = $this->session->sysparam->smtpauth[0];
         $mail->SMTPSecure = $this->session->sysparam->smtpsecure[0];
         $mail->Username = $this->session->sysparam->smtpuser[0];
         $mail->Password = $this->session->sysparam->smtppasswd[0];
         $mail->Port = $this->session->sysparam->smtpport[0];
     
         /* Set the mail sender. */
         $mail->setFrom($this->session->sysparam->smtpuser[0], 'POSTMASTER');
      
         /* Add a recipient. */
         foreach($tos as $t1=>$t2) {
           $mail->addAddress($t2->email, $t2->email);
         }
      
         /* Set the subject. */
         $mail->Subject = $this->session->sysparam->group_verifikator[$next]->subject;
      
         /* Set the mail message body. */
         $mail->isHTML(TRUE);
         
         if ($pesan == '' ) {
           $tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[$next]->url."?q=".$post->app_t_usulan_cnousul."'>disini</a>";
           
           $pesan = str_replace("__tautan__", $tautan, $this->session->sysparam->group_verifikator[$next]->msg);
         }
         
         $mail->Body = $pesan;
         //print_r($mail);
         //exit;
         /* Finally send the mail. */
         $mail->send();
         $status = true;
         // 'Email Terkirim';
      }
      catch (Exception $e)
      {
         /* PHPMailer exception. */
         $status = false;
         $pesan = $e->errorMessage();
      }
      catch (\Exception $e)
      {
         /* PHP exception (note the backslash to select the global namespace Exception class). */
         $status = false;
         $pesan = $e->getMessage();
      }
  	  
  	  $datas = [
  	       'status' => $status,
  	       'msg' => $pesan
  	     ];
  	     
  	  //return $datas;
  	  //print_r($datas);exit;
    }

	function get_detail_surat_sinde() {
		$nosurat = trim($this->input->post('nosurat'));
		$datas = array();

		$this->load->library('rest');
		$config = array(
			'server' => "https://persuratan.kemdikbud.go.id",
			'api_key'	=> "b9729656-be4d-5700-9193-dcd3dbe1d1f3",
            'api_name'	=> "X-API-KEY"
		);

		$this->rest->initialize($config);

		$result = $this->rest->post('api_arsip/getToken', 
			array(
				'client-id'=>'4ebd0208-8328-5d69-8c44-ec50939c0967', 
				'client-secret'=>'b895ecbc-c152-4815-991a-d50ea6b20b82'), false
		);
		$result = json_decode($result);
		$token = $result->data->access_token;

		//echo 'token : '.$token;
		//exit;

		
		$config = array(
			'server' => "https://persuratan.kemdikbud.go.id",
			'api_key'	=> trim($token),
            'api_name'	=> "bearer"
		);
		$this->rest->initialize($config);
		//$this->rest->http_header('User-agent', $_SERVER['HTTP_USER_AGENT']);
		//$this->rest->http_header('bearer',$token);
		$result2 = $this->rest->post('api_arsip/getDataSurat', 
			array(
				'nosurat' => trim($nosurat)
			));

		$result2 = json_decode($result2);

		$config = array(
			'server' => "https://persuratan.kemdikbud.go.id",
			'api_key'	=> $token,
            'api_name'	=> "bearer"
		);
		$this->rest->initialize($config);
		//$this->rest->http_header('User-agent', $_SERVER['HTTP_USER_AGENT']);
		//$this->rest->http_header('bearer',$token);
		$result3 = $this->rest->post('api_arsip/getDataLampiranSurat', 
			array(
				'nosurat' => trim($nosurat)
			));

		$result3 = json_decode($result3);

		$datas = [
			'nosurat' => $result2->data->nosurat,
			'tglsurat' => date('d-m-Y', strtotime($result2->data->tglsurat)),
			'idsurat' => $result2->data->idsurat,
			'namafile' => $result3->data->lampiran[0]->namafile,
			'isifile' => $result3->data->lampiran[0]->isifile,
		];

		//print_r($datas);exit;
		echo json_encode($datas);exit;
	}

	function insertBox_app_t_usulan_cnousul($name) {
		$input  = "<input type='text' class='form-control {$name}' 
					id='{$name}' name='{$name}' placeholder='No. Usul Surat'>"; // style='width:400px;'
		/* $input .= " <div style='margin-top:-28px;margin-left:405px;'>
						<button onclick='get_detail_surat_sinde();'type='button' id='btn_{$name}' name='btn_{$name}' class='btn_{$name}'>
						<i class='fas fa-mail-bulk'></i> Detail Surat Dari SINDE</button>
					</div>"; */

	  return $input;
	}

	function updateBox_app_t_usulan_cnousul($name, $value, $datas) {
		$input  = "<input type='text' class='form-control {$name}' 
					id='{$name}' name='{$name}' placeholder='No. Usul Surat' value='{$value}'>";//style='width:400px;' 
		/* $input .= " <div style='margin-top:-28px;margin-left:405px;'>
						<button onclick='get_detail_surat_sinde();'type='button' id='btn_{$name}' name='btn_{$name}' class='btn_{$name}'>
						<i class='fas fa-mail-bulk'></i> Detail Surat Dari SINDE</button>
					</div>"; */

	  return $input;
	}

	function create_surat_from_template($datas=null, $template='template_perubahan.docx') {

		//ini_set('display_errors', 1);
		//error_reporting(E_ALL);
		$upload_path = $this->session->sysparam->upload_path[0];
		$kode_unor = trim($datas['datanya']['kode_unor']);
		$no_surat = str_replace("/", "_", trim($datas['datanya']['no_surat']));
		$filename = str_replace("\\", "/", realpath('template/docx')).'/'.$template;
		$templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor($filename);

		/*
			'no_surat'=> str_replace("/", "_", $post->app_t_usulan_cnousul),
			'tgl_bln_thn'=>$this->nama_bulan_indonesia(date('d-m-Y', strtotime($post->app_t_usulan_dtglusul))),
			'unit_kerja'=>ucwords(strtolower($nama_unor)),
			'nama_pejabat_ttd'=>$nama_pejabat_ttd,
			'nip_pejabat_ttd'=>$nip_pejabat_ttd
		*/


		$datanya = [
			'ta' =>$datas['datanya']['ta'],
			'no_surat' => $datas['datanya']['no_surat'],
			'nama_satker' => $datas['datanya']['unit_kerja'],
			'tgl_bln_thn' => $datas['datanya']['tgl_bln_thn'],
			'jabatan_nama_satker'=>$datas['datanya']['jabatan_nama_satker'],
			'nama_pejabat_ttd'=>$datas['datanya']['nama_pejabat_ttd'],
			'nip_pejabat_ttd'=>$datas['datanya']['nip_pejabat_ttd']
		];

		$templateProcessor->setValues($datanya);

		//print_r($datas['block']);exit;
		/*
		'norut' => $norut, 
					'jenis_jabatan' => $r->jabatan2_new,
					'nama_old' => $nama_dgn_gelar, 
					'nip_old' => $r->nip_old, 
					'pangkat_old' => $r->pangkat_old, 
					'jabatan_old' => (
										trim($r->jabatan2_old) != trim($this->session->sysparam->beda_jabatan[0]) ? 
										trim($r->jabatan2_old) : trim($r->jabatan_old)
									),
					'nama_new' => $nama_dgn_gelar, 
					'nip_new' => $r->nip_new, 
					'pangkat_new' => $r->pangkat_new, 
					'jabatan_new' => (
										trim($r->jabatan2_new) != trim($this->session->sysparam->beda_jabatan[0]) ? 
										trim($r->jabatan2_new) : trim($r->jabatan_new)
									)
		*/
		//$templateProcessor->cloneBlock('block_informasi_pejabat', 0, true, false, $datas['block']);
		//$templateProcessor->cloneRow('norut', 3);
		//print_r($dataRows);exit;

		$cellRowSpan = array('vMerge' => 'restart');
		$cellRowContinue = array('vMerge' => 'continue');
		$cellColSpan = array('gridSpan' => 3);
		
		$cols = array('norut'=>array('NO.', 700),
				'sebelumnya'=>array('SEBELUMNYA', 5500),
				'menjadi'=>array('MENJADI', 4500));

		$table = new PhpOffice\PhpWord\Element\Table(array('borderSize'=>5, 
				'borderColor'=>'black', 'unit' => PhpOffice\PhpWord\SimpleType\TblWidth::TWIP));
		//$cellHeaderStyle = array('align'=>'center', 'vMerge' => 'restart');
		$cellHeaderStyle = array('align'=>'center');
		$cellHeaderFont = array('bold'=>true);
		$table->addRow();
		$xx = 0;
		foreach($cols as $k=>$c) {
				
			/*$table->addCell($c[1], $cellHeaderStyle)
				->addText($c[0], $cellHeaderFont, 
				['align' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER,
				'valign' => 'center']);*/
			if ( $xx == 0 ) $cells = $cellHeaderStyle;
			else $cells = $cellColSpan;

			$table->addCell($c[1], $cells)
				->addText($c[0], $cellHeaderFont, 
				['align' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER,
				'valign' => 'center']);

			//$cell1 = $table->addCell($c[1], $cells);
			//$textrun1 = $cell1->addTextRun($cellHeaderFont);
			//$textrun1->addText($c[0]);
			
			$xx++;
			//$table->addCell(2000, $cellRowSpan)->addText("1");
		}

		$dataRows = $datas['block'];
		
		$cellColSpan = array('gridSpan' => 6, 'valign' => 'center');
		$cellHLEFT = array('alignment' => 'left');
		$cellHCENTER = array('alignment' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER);
		$cellVCentered = array('valign' => 'center');
		//print_r($dataRows);exit;

		/*
    [0] => Array
        (
            [norut] => 1
            [jenisjabatan] => Kuasa Pengguna Anggaran
            [uraian_nama] => Array
                (
                    [namaold] => AMBAR INDRIANI, S.E.
                    [namanew] => DRS Triyantoro
                )

            [uraian_nip] => Array
                (
                    [nipold] => 196602221985032001
                    [nipnew] => 196811131993031002
                )

            [uraian_pangkat] => Array
                (
                    [pangkatold] => Penata Tingkat I, III/d
                    [pangkatnew] => Pembina Tingkat I, IV/b
                )

            [uraian_jabatan] => Array
                (
                    [jabatanold] => Penelaah Kebijakan Pengadaan Barang/Jasa
                    [jabatannew] => Pengelola Pengadaan Barang/Jasa Ahli Madya
                )

        )
		*/
		foreach($dataRows as $dr) {
			$table->addRow();


			$cell1 = $table->addCell(700, null);
			$textrun1 = $cell1->addTextRun($cellHCENTER);
			$textrun1->addText($dr['norut']);

			$cell2 = $table->addCell(9000, $cellColSpan);
			$textrun2 = $cell2->addTextRun($cellHLEFT);
			$textrun2->addText($dr['jenisjabatan']);

			/*$cell3 = $table->addCell(4500, $cellColSpan);
			$textrun3 = $cell3->addTextRun($cellHLEFT);
			$textrun3->addText(null);*/

			/*$table->addCell(9000, $cellColSpan)->addText($dr['jenisjabatan'], array('bold'=>false), 
			['align' => 'left',
			'valign' => 'center']);*/

			$nama_old = $dr['uraian_nama']['namaold'];
			$nip_old  = $dr['uraian_nip']['nipold'];
			$pangk_old = $dr['uraian_pangkat']['pangkatold'];
			$jab_old = $dr['uraian_jabatan']['jabatanold'];

			$nama_new = $dr['uraian_nama']['namanew'];
			$nip_new  = $dr['uraian_nip']['nipnew'];
			$pangk_new = $dr['uraian_pangkat']['pangkatnew'];
			$jab_new = $dr['uraian_jabatan']['jabatannew'];


			if ( empty($nama_old) ) $nama_old = $nama_new;
			if ( empty($nip_old) ) $nip_old = $nip_new;
			if ( empty($pangk_old) ) $pangk_old = $pangk_new;
			if ( empty($jab_old) ) $jab_old = $jab_new;


			if ( empty($nama_new) ) $nama_new = $nama_old;
			if ( empty($nip_new) ) $nip_new = $nip_old;
			if ( empty($pangk_new) ) $pangk_new = $pangk_old;
			if ( empty($jab_new) ) $jab_new = $jab_old;

			if ( (int)$dr['perubahan'] == 1 ) {
				//tambah jabatan
				$nama_old = '-';
				$nip_old  = '-';
				$pangk_old = '-';
				$jab_old = '-';
			} else if ( (int)$dr['perubahan'] == 2 ) {
				$nama_new = '-';
				$nip_new  = '-';
				$pangk_new = '-';
				$jab_new = '-';
			} else {
				//do nothing
			}



			
			//NAMA
			$table->addRow();
			$table->addCell(700, $cellVCentered)->addText('');
			$table->addCell(1600, $cellVCentered)->addText('Nama', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($nama_old, null, $cellHLEFT);

			$table->addCell(1600, $cellVCentered)->addText('Nama', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($nama_new, null, $cellHLEFT);


			//NIP
			$table->addRow();
			$table->addCell(700, $cellVCentered)->addText('');
			$table->addCell(1600, $cellVCentered)->addText('NIP', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($nip_old, null, $cellHLEFT);

			$table->addCell(1600, $cellVCentered)->addText('NIP', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($nip_new, null, $cellHLEFT);


			//PANGKAT/GOLONGAN
			$table->addRow();
			$table->addCell(700, $cellVCentered)->addText('');
			$table->addCell(1600, $cellVCentered)->addText('Pangkat/Golongan', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($pangk_old, null, $cellHLEFT);

			$table->addCell(1600, $cellVCentered)->addText('Pangkat/Golongan', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($pangk_new, null, $cellHLEFT);


			//JABATAN
			$table->addRow();
			$table->addCell(700, $cellVCentered)->addText('');
			$table->addCell(1600, $cellVCentered)->addText('Jabatan', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($jab_old, null, $cellHLEFT);

			$table->addCell(1600, $cellVCentered)->addText('Jabatan', null, $cellHLEFT);
			$table->addCell(250, $cellVCentered)->addText(':', null, $cellHLEFT);
			$table->addCell(2650, $cellVCentered)->addText($jab_new, null, $cellHLEFT);

		}

		$templateProcessor->setComplexBlock('{informasi_pegawai}', $table);
		//print_r($dataRows);exit;
		//$templateProcessor->cloneRow('norut', 3);
		//$templateProcessor->cloneRowAndSetValues('{norut}', $dataRows);
		
		//echo 'nosk : '.$no_sk;
		$nama_file = $kode_unor.'.docx';
		$path = realpath($upload_path).'/'.$nama_file;

		//echo $path;exit;
		
		//echo $path;
		$templateProcessor->saveAs($path);

		//echo 'test';exit;
		
		$file    = file_get_contents($path);
		$escaped = base64_encode($file);//pg_escape_bytea($data);
		
		//convert ke PDF
		//$nama_file2pdf = $kode_unor.'.pdf';
		//$path2pdf = realpath($upload_path).'/'.$nama_file2pdf;
		
		//$convert_path = $this->session->sysparam->convert_home[0]; 
		/*
        ** UNTUK WINDOWS 
        $tempLibreOfficeProfile = str_replace('\\', '/', realpath($upload_path));
		$libreoffice_home = $this->session->sysparam->libreoffice_home[0];
		//$cmd = "start /B ".$convert_path." \"".$libreoffice_home."\"  \"".$tempLibreOfficeProfile."\" \"".$tempLibreOfficeProfile."/".$nama_file."\"";
		$cmd = "\"".$convert_path."\" \"".$libreoffice_home."\"  \"".$tempLibreOfficeProfile."\" \"".$tempLibreOfficeProfile."/".$nama_file."\"";
		//echo $cmd;exit;
        exec($cmd, $result);
        /* END UNTUK WINDOWS **/

        /*
        /** UNTUK LINUX
        $tempLibreOfficeProfile = realpath($upload_path);
        $cmd = "sh \"".$convert_path."\" \"".$tempLibreOfficeProfile."\" \"".$nama_file."\"";
        echo $cmd;
        //exit;
        exec($cmd);
        /** END UNTUK LINUX **/
	  
		//$file2pdf    = file_get_contents($path2pdf);
		//$escaped2pdf = base64_encode($file2pdf);//pg_escape_bytea($data);
		$escaped2pdf = null;


		unlink($path);
		//unlink($path2pdf);
		
		return array('file1'=>$escaped, 'file2'=>$escaped2pdf);
		//exec('doc2pdf '.$path, $output, $retval);
	}
}
