<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* Namespace alias. */
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class T_usulan_approval extends MX_Controller {
  var $prefix = 'app';
  var $ar_statusid = array();
  var $ar_statusperubahan = array();
  

	public function __construct() {
		parent::__construct();
		$controller = "perbend/t_usulan_approval";
		$table  = $this->prefix."_t_usulan";

		$this->_setModal(true);
   		$this->_setTitle('Usulan Approval');
		$this->_setController($controller);
		$this->_init('default');

        $checkbox1 = "<input type='checkbox' name='check_all' id='check_all' onchange='klik_all(this, 1);'/><br/>Setujui";
		$checkbox2 = "<input type='checkbox' name='check_all2' id='check_all2' onchange='klik_all(this, 2);'/><br/>Tolak";

		$this->_addTable($table);
		$this->_addField($table, 'id', '', true, true);
		$this->_addField($table, 'ijns', 'Jenis Usulan', false, true);
		$this->_addField($table, 'iunorid', 'Satuan Kerja', true);		
        $this->_addField($table, 'check', $checkbox1, false, true, true);
		$this->_addField($table, 'check2', $checkbox2, false, true, true);
		$this->_addField($table, 'cnousul', 'No. Usul', true);
		$this->_addField($table, 'dtglusul', 'Tgl. Usul', true);
		$this->_addField($table, 'istatusid', 'Status Perubahan', true);
		$this->_addField($table, 'ijnsprubhnid', 'Jenis Perubahan', true);
		$this->_addField($table, 'lampiran', 'Lampiran Surat Usulan (dlm format PDF)', false, false, true);
		$this->_addField($table, 'tfile', 'Lampiran', true, true);
		$this->_addField($table, 'vtype', 'Tipe Dokumen', false, true);
		$this->_addField($table, 'nsize', 'nsize', false, true);
		$this->_addField($table, 'istatus', 'Status Usulan', false, true);
		$this->_addField($table, 'daftarnama', '', false, false, true, 0, 'left', '','', true);
		$this->_addField($table, 'tcreated', 'Waktu dibuat', false, true);
		$this->_addField($table, 'ccreatedby', 'Dibuat oleh', false, true);
		$this->_addField($table, 'tupdated', 'Waktu ubah', false, true);
		$this->_addField($table, 'cupdatedby', 'Diubah oleh', false, true);
		$this->_addField($table, 'ctahun', 'ctahun', false, true);

		//$this->_add2SearchField($table, 'cnip');
		//$this->_add2SearchField($table, 'vname');
		//$this->_add2SearchField($table, 'ldeleted');
		
		$rows = $this->getall('', $this->prefix.'_m_status', '*', array('ldeleted'=>0));
		foreach($rows as $r) {
		$this->ar_statusid[$r->id] = $r->vdesc;
		}
		
		$this->_changeType($table, 'istatusid', 'combobox', 
		$this->ar_statusid);
		
		$rows = $this->getall('', $this->prefix.'_m_perubahan', '*', array('ldeleted'=>0));
		foreach($rows as $r) {
		$this->ar_statusperubahan[$r->id] = $r->vdesc;
		}
		
		$this->_changeType($table, 'ijnsprubhnid', 'combobox', 
		$this->ar_statusperubahan);
		
		$this->_changeType($table, 'istatus', 'combobox', 
		$this->session->sysparam->status_usulan);

		$this->_changeType($table, 'ijns', 'combobox', 
		$this->session->sysparam->jenis_usulan);
		
		$this->_changeType($table, 'dtglusul', 'date', 'd-m-Y');
		
		$this->_add2SearchField($table, 'ijns');
		$this->_add2SearchField($table, 'cnousul');
		$this->_add2SearchField($table, 'dtglusul');
		$this->_add2SearchField($table, 'istatusid');
		$this->_add2SearchField($table, 'ijnsprubhnid');
		
		$this->_setAlign($table, 'check', 'center', 'top');
		$this->_setAlign($table, 'check2', 'center', 'top');
		$this->_setAlign($table, 'dtglusul', 'center');
		//$this->_setAlign($table, 'istatus', 'center');
		$this->_setAlign($table, 'istatusid', 'center');
		$this->_setAlign($table, 'ijnsprubhnid', 'center');
		$this->_setAlign($table, 'tfile', 'center');
		
		$this->_addQuery($table, 'app_t_usulan.istatus = 3', 'and', '', 'true');
		$this->_addQuery($table, "app_t_usulan.ctahun = '{$this->session->settahun}'", 'and', '', true);
    
		$this->_add2ListField($table, 'check, check2, ijns, iunorid, cnousul, dtglusul, istatusid, ijnsprubhnid, tfile, tupdated, cupdatedby');

		$this->_addOrderBy($table, ['tcreated'=>'asc']);
		//clear session header_controller
		$this->session->unset_userdata('header_controller');
	}

	function viewBox_app_t_usulan_iunorid($name, $value) {
		$name_txt = $this->getrow('', 'kepeg_m_unor', 'nama', array('kode_satker'=>$value))->nama;
		$html = "<p class='form-control-static {$name}'>".$name_txt."</p>";
		return $html;
	}

	function listBox_app_t_usulan_iunorid($value) {
		$name_txt = $this->getrow('', 'kepeg_m_unor', 'nama', array('kode_satker'=>$value))->nama;
		return $name_txt;
	}
	
	function listBox_app_t_usulan_tupdated($value, $datas) {
	  if ( $value != null ) {
	    return date('d-m-Y H:i:s', strtotime($value));
	  } else return date('d-m-Y H:i:s', strtotime($datas->app_t_usulan_tcreated));
	}
	
	function listBox_app_t_usulan_cupdatedby($value, $datas) {
	  if ( $value != null ) {
	    $nama = $this->getrow($this->db, 'priv_t_user', 'realname', array('username'=>trim($value)))->realname;
	   } else {
	     $nama = $this->getrow($this->db, 'priv_t_user', 'realname', array('username'=>trim($datas->app_t_usulan_ccreatedby)))->realname;
	   }
	  
	  return $nama;
	}

	public function after_insert_processor($id, $post) {
		$new_post = array();
		$new_post['tcreated']   = date('Y-m-d H:i:s');
		$new_post['ccreatedby'] = $this->session->userdata['username'];

		$this->db->where('id', $id);
		$this->db->update($this->prefix.'_t_usulan', $new_post);
	}

	public function after_update_processor($id, $post, $oldpost) {
		$new_post = array();
		$new_post['tupdated']   = date('Y-m-d H:i:s');
		$new_post['cupdatedby'] = $this->session->userdata['username'];

		$this->db->where('id', $id);
		$this->db->update($this->prefix.'_t_usulan', $new_post);
	}
	
	function listBox_ACTION($buttons, $datas) {
	  unset($buttons['hapus']);
	  if ( $datas->app_t_usulan_istatus > 0 ) unset($buttons['ubah']);
    
      if ( $datas->app_t_usulan_jns == 1 ) {
        $buttons['lihat'] = "<span style='text-align: center;cursor:pointer;' onclick=\"view('".base_url().$this->router->fetch_module()."/".$this->router->class."/view/".$datas->app_t_usulan_id."', '".strtolower($this->router->class)."');\" data-toggle='modal' data-target='#".strtolower($this->router->class)."_form-modal'>
							<i class='fas fa-search' title='Lihat'></i>
						</span>";
      } else {
        $buttons['lihat'] = "<span style='text-align: center;cursor:pointer;' onclick=\"view('".base_url().$this->router->fetch_module()."/t_usulan_satker2/view/".$datas->app_t_usulan_id."', '".strtolower($this->router->class)."');\" data-toggle='modal' data-target='#t_usulan_satker2_form-modal'>
							<i class='fas fa-search' title='Lihat'></i>
						</span>";
      }
	  
	  return $buttons;
	}
	
	public function insertBox_app_t_usulan_lampiran($name) {
		$input = "<input type='file' name='{$name}' id='{$name}' class='form-control {$name}' accept='application/pdf'/>";
		$input .= $this->session->sysparam->info_max_upload[0];
		return $input;
	}
	
	function listBox_app_t_usulan_tfile($value, $datas) {
	  $input = "";
	  
	  $vtype = trim($datas->app_t_usulan_vtype);
	  $tfile = $value;
	  
	  if ( !empty($value) ){
			$input .= "<span data-toggle='modal' data-target='#myPreview_{$datas->app_t_usulan_id}' style='cursor:pointer;' class='label label-primary'>
						<b>Surat Usulan</b>
					  </span>";
  	  $input .= "<div class='modal fade' id='myPreview_{$datas->app_t_usulan_id}' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
  				   <div class='modal-dialog' role='document' style='width:65%;'>
  					 <div class='modal-content'>
  					   <div class='modal-header'>
  						 <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
  						 <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Surat Usulan {$datas->app_t_usulan_cnousul}</h4>
  					   </div>
  					   <div class='modal-body' id='modal-body'>
  						 <div class='form-group'>
  							 <div id='html_telusuri'>";
  
  		if ( $vtype != 'application/pdf' ) {
  			$height='100';$width='';
  		} else { $height='100%';$width='700';}
  
  		$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";
  
  
  		$input .= "			 </div>
  						 </div>
  					   </div>
  					</div>
  				</div>
  			</div>";
	  }
	  
		return $input;
	}

	public function updateBox_app_t_usulan_lampiran($name, $value, $datas) {
		$tfile = $datas->app_t_usulan_tfile;
		$vtype = trim($datas->app_t_usulan_vtype);

		$input = "<input type='file' name='{$name}' id='{$name}' class='form-control {$name}' accept='application/pdf'/>";
		$input .= $this->session->sysparam->info_max_upload[0];
		if ( !empty($tfile) ){
			$input .= "<br/><span data-toggle='modal' data-target='#myPreview' style='cursor:pointer;' class='label label-primary'>
						<b>Surat Usulan</b>
					  </span>";
		}

		$input .= "<div class='modal fade' id='myPreview' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
				   <div class='modal-dialog' role='document' style='width:65%;'>
					 <div class='modal-content'>
					   <div class='modal-header'>
						 <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
						 <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Surat Usulan {$datas->app_t_usulan_cnousul} </h4>
					   </div>
					   <div class='modal-body' id='modal-body'>
						 <div class='form-group'>
							 <div id='html_telusuri'>";

		if (trim($vtype) != 'application/pdf' ) {
			$height='100';$width='';
		} else { $height='100%';$width='700';}

		$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";


		$input .= "			 </div>
						 </div>
					   </div>
					</div>
				</div>
			</div>";

		
		return $input;
	}

	public function viewBox_app_t_usulan_lampiran($name, $value, $datas) {
		$tfile = $datas->app_t_usulan_tfile;
		$vtype = trim($datas->app_t_usulan_vtype);
		$input = "";
		
		if ( !empty($tfile) ){
			$input .= "<br/><span data-toggle='modal' data-target='#myPreview' style='cursor:pointer;' class='label label-primary'>
						<b>Surat Usulan</b>
					  </span>";
		}

		$input .= "<div class='modal fade' id='myPreview' role='dialog' aria-labelledby='myModalLabel' data-backdrop='static' data-keyboard='false'>
				   <div class='modal-dialog' role='document' style='width:65%;'>
					 <div class='modal-content'>
					   <div class='modal-header'>
						 <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
						 <h4 class='modal-title' id='myModalLabel'><i class='glyphicon glyphicon-tasks'></i> Preview </h4>
					   </div>
					   <div class='modal-body' id='modal-body'>
						 <div class='form-group'>
							 <div id='html_telusuri'>";

		if (trim($vtype) != 'application/pdf' ) {
			$height='100';$width='';
		} else { $height='100%';$width='700';}

		$input .= "<embed src='data:{$vtype};base64,{$tfile}' type='{$vtype}' width='{$height}' height='{$width}' alt='{$vtype}'>";


		$input .= "			 </div>
						 </div>
					   </div>
					</div>
				</div>
			</div>";

		
		return $input;
	}
	
	public function before_insert_processor($post) {
		$files = $this->uploadfiles($_FILES['app_t_usulan_lampiran']);
		if ( !empty($files->file) ) {
			$post->app_t_usulan_tfile = $files->file;
			$post->app_t_usulan_vtype = $files->type;
			$post->app_t_usulan_nsize = $files->size;
		}
		return $post;
	}
	
	public function before_update_processor($id, $post) {
		$files = $this->uploadfiles($_FILES['app_t_usulan_lampiran']);
		if ( !empty($files->file) ) {
			$post->app_t_usulan_tfile = $files->file;
			$post->app_t_usulan_vtype = $files->type;
			$post->app_t_usulan_nsize = $files->size;
		}
	
		return $post;
	}
	
	function insertCheck_app_t_usulan_tfile($value, $post) {
		$data['status'] = true;
		if ( !empty($value) ) {
				if ( trim($post->app_t_usulan_vtype) != 'application/pdf' ) {
					$data['status']  = false;
					$data['msg'] = 'Lampiran wajib dalam format PDF';
					$data['obj'] = 'app_t_usulan_lampiran';
				} else if ( $files->size > (int)$this->session->sysparam->max_size_upload[0] ) {
					$data['status']  = false;
					$data['msg'] = str_replace('__upload__', 'Lampiran Surat Usulan (dlm format PDF)', $this->session->msg_max_size_upload_tercapai[0]);
					$data['obj'] = 'app_t_usulan_lampiran';
				}
		}

		return $data;
	}
	
	function updateCheck_app_t_usulan_tfile($value, $post, $id) {
	  return $this->insertCheck_app_t_usulan_tfile($value, $post);
	}
	
	public function manipulate_update_button($buttons, $datas) {
	  $btn_simpankirim = "<button type='submit' id='btn_send' class='btn btn-primary' style='{$style}' 
								onclick='tinyMCE.triggerSave(true,true);$(\"#t_usulan_approval_form-edit #app_t_usulan_istatus\").val(1);'>
										<i class='glyphicon glyphicon-send'></i>&nbsp;Simpan & Kirim
									</button>";

		$buttons['simpan'] .= $btn_simpankirim;
		//array_push($buttons, $btn_simpankirim);

		return $buttons;
	}
	
	/*function manipulate_view_button($buttons, $datas) {
	  print_r($buttons);
	}*/
	
	function gettotaldaftarpegawai($iusulanid) {
		return $this->getrow('', 'app_t_usulan_pegawai', 'count(*) as total', array('iusulanid'=>$iusulanid))->total;
	}
	
	function after_delete_processor($id) {
		$where = array('iusulanid'=>$id);
		$this->dbpeng->where($where);
		$this->dbpeng->delete('t_usulan_pegawai');
	}

	public function viewBox_app_t_usulan_daftarnama($name, $value, $datas) {
		$html = "<div>
				<ul class='nav nav-tabs' role='tablist' id='all_tabs'>
				  <li role='presentation' class='active'>
					  <a href='#tab1' data-toggle='tab' aria-controls='tab1' role='tab'>Daftar Pegawai</a>
				  </li>
				</ul>
			  
				<div class='tab-content'>
				  <div role='tabpanel' class='tab-pane fade in active' id='tab1'></div>
				</div>
			  </div>";
			  
	  	$html .= "<script type='text/javascript'>
				  $(document).ready(function() {
					  //tab 1
					  url = '".base_url()."perbend/t_usulan_daftar/index';
					  $('#tab1').html(getHTML(url, '', 0, false));
					  $('#t_usulan_daftar #q_app_t_usulan_pegawai_iusulanid').val($('.app_t_usulan_id').val());
					  $('#t_usulan_daftar #q_app_t_usulan_pegawai_ispelatihan').val(0);
				  });
				  
				</script>";				
			  
	  return $html;	
	}

    function listBox_app_t_usulan_check($value, $datas) {
        $input = "<input onchange='klik(this,1);' type='checkbox' name='check_usulan1[]' id='check_usulan1_{$datas->app_t_usulan_id}' class='check_usulan1'/>";
        $input .= "<input type='hidden' name='id_usulan1[]' id='id_usulan1_{$datas->app_t_usulan_id}' class='id_usulan1' value='{$datas->app_t_usulan_id}'/>";
        $input .= "<input type='hidden' name='check_usulan1_status[]' id='check_usulan1_status_{$datas->app_t_usulan_id}' class='check_usulan1_status' />";

        return $input;
    }

	function listBox_app_t_usulan_check2($value, $datas) {
        $input = "<input onchange='klik(this,2);' type='checkbox' name='check_usulan2[]' id='check_usulan2_{$datas->app_t_usulan_id}' class='check_usulan2'/>";
		$input .= "<input type='hidden' name='id_usulan2[]' id='id_usulan2_{$datas->app_t_usulan_id}' class='id_usulan2' value='{$datas->app_t_usulan_id}'/>";
        $input .= "<input type='hidden' name='check_usulan2_status[]' id='check_usulan2_status_{$datas->app_t_usulan_id}' class='check_usulan2_status' />";
		$input .= "<div class='div_alasan_usulan2' style='display:none;'>
					<textarea name='alasan_usulan2[]' id='alasan_usulan2_{$datas->app_t_usulan_id}' class='alasan_usulan2'></textarea>
				   </div>";

        return $input;
    }

	function listBox_app_t_usulan_ijns($value, $datas) {
		$nama_txt = $this->session->sysparam->jenis_usulan[$value];
		$input = "<input type='hidden' name='check_usulan_jenis[]' id='check_usulan_jenis_{$datas->app_t_usulan_id}' class='check_usulan_jenis' value='{$value}'/>";
		return $input.$nama_txt;
	}

    function app_t_usulan_output(){
        $js ="<script type='text/javascript'>
                  $(document).ready(function() {
                      
                  });

                  function klik_all(a, b) {
                    if ( $(a).is(':checked') ) {
						if ( b == 1 ) {
							//alert('1');
							$('.check_usulan1').prop('checked', true);
							$('.check_usulan1_status').val(4);

							$('.check_usulan2').prop('checked', false);
							$('.check_usulan2').prop('disabled', true);
							$('#check_all2').prop('disabled', true);

							$('.alasan_usulan2').value('');
							$('.div_alasan_usulan2').css('display', 'none');
						} else {
							//alert('2');
							$('.check_usulan2').prop('checked', true);
							$('.check_usulan2_status').val(5);

							$('.check_usulan1').prop('checked', false);
							$('.check_usulan1').prop('disabled', true);
							$('#check_all').prop('disabled', true);

							$('.div_alasan_usulan2').css('display', 'block');

						}		
                    } else {
						if ( b == 1 ) {
							//alert('3');
							$('.check_usulan1').prop('checked', false);
							$('.check_usulan1_status').val(0);

							$('.check_usulan2').prop('disabled', false);
							$('#check_all2').prop('disabled', false);
							
						} else {
							//alert('4');
							$('.check_usulan2').prop('checked', false);
							$('.check_usulan2_status').val(0);
							
							$('.check_usulan1').prop('disabled', false);
							$('#check_all').prop('disabled', false);

							$('.alasan_usulan2').html('');
							$('.div_alasan_usulan2').css('display', 'none');
							
						}
					}
                  }

                  function klik(dis, b) {

					if ( b == 1 ) {
						var i = $('.check_usulan1').index(dis);
						var id = $('.id_usulan1').eq(i).val();
						if ( $('.check_usulan1').eq(i).is(':checked') ) {
							$('.check_usulan1_status').eq(i).val(4);
							$('.check_usulan2').eq(i).prop('disabled', true);
						} else { 
							$('.check_usulan1_status').eq(i).val(0);
							$('.check_usulan2').eq(i).prop('disabled', false);
						}
                    } else {
						var i = $('.check_usulan2').index(dis);
						var id = $('.id_usulan2').eq(i).val();
						if ( $('.check_usulan2').eq(i).is(':checked') ) {
							$('.check_usulan2_status').eq(i).val(5);
							$('.check_usulan1').eq(i).prop('disabled', true);

							$('.div_alasan_usulan2').eq(i).css('display', 'block');
						} else { 
							$('.check_usulan2_status').eq(i).val(0);
							$('.check_usulan1').eq(i).prop('disabled', false);

							$('.alasan_usulan2').eq(i).html('');
							$('.div_alasan_usulan2').eq(i).css('display', 'none');
						}
					}
                  }

          function save_persetujuan(url, table_id, default_txt_confirm='Simpan. Anda yakin?', _ismodal=false, _modals='form-modal', _islochref=false, _isneedrefresh=true, _isOldFashion=false, _msg='Simpan Persetujuan berhasil.') {

					var id = 0;
					var total1 = 0;
					var total2 = 0;
					var alasan = '';
					var blok = false;
					$('.check_usulan1').each(function() {
						var i = $('.check_usulan1').index(this);
						if ( $(this).is(':checked') ) {
							total1++;
						}
					});

					$('.check_usulan2').each(function() {
						var i = $('.check_usulan2').index(this);
						if ( $(this).is(':checked') ) {
							total2++;
							if ( $('.alasan_usulan2').eq(i).val() == '' ) {
								bootbox_alert('', '', 'Penolakan harap di sertai dengan alasan.', false, false);
								blok = true;
								return false;
							}
						}
					});

					if ( blok == false ) {
						if ( (total1 + total2) == 0 ) {
							bootbox_alert('', '', 'Tidak ada data yang dipilih', true, false);
							return false;	
						}
					} else return false;

                    if ( default_txt_confirm == '' ) default_txt_confirm='Simpan. Anda yakin?';
                    var form_name = table_id+'_list-edit';
                    var formData = new FormData(jQuery('#'+form_name)[0]);
                    save_confirm(url+'/save_persetujuan', formData, default_txt_confirm, table_id, _ismodal, function(output) {
                        var o = jQuery.parseJSON(output);
                        $('div').removeClass('has-error');
                        if ( o.status ) {
                            //bootbox.alert(_msg);
                            bootbox_alert('', '', _msg, true);
                            reload_grid('".base_url()."perbend/t_usulan_approval/lists', 't_usulan_approval');
    
                            /*setTimeout(function(){ $('body').css('padding-right', 0); }, 1000);*/
                            setTimeout(location.reload(true), 2000);
                            
                        } else {
                            if ( o.msg != undefined) bootbox.alert(o.msg);
                            $('.'+o.obj).focus();
                            $('div .'+o.obj).addClass('has-error');
                            if ( _ismodal ) $('#'+_modals).css('overflow', 'scroll')
                            return false;
                        }
                    });
                }
            </script>";
  
        return $js;
    }

    function manipulate_list_button($buttons) {
        $buttons['add'] = "<button type='button' onclick='save_persetujuan(\"".base_url()."perbend/t_usulan_approval\", \"t_usulan_approval\")' class='btn btn-primary' name='save_checklist' id='save_checklist' class='form-control save_checklist'>
                            <i class='fas fa-save'></i> Simpan Persetujuan
                           </button>";

        return $buttons;
    }

    function save_persetujuan() {
        //print_r($_POST);
        //exit;

		    $check_usulan_jenis = array();

        $id_usulan1 = array();
        $check_usulan1_status = array();
		
		    $id_usulan2 = array();
        $check_usulan2_status = array();
		    $alasan_usulan2 = array();

        foreach($_POST as $key=>$value) {
            if ( $key == 'id_usulan1') {
                foreach($value as $k=>$v) {
                    $id_usulan1[$k] = $v;
                }
            }

            if ( $key == 'check_usulan1_status') {
                foreach($value as $k=>$v) {
                    $check_usulan1_status[$k] = $v;
                }
            }

			    if ( $key == 'check_usulan_jenis') {
                foreach($value as $k=>$v) {
                    $check_usulan_jenis[$k] = $v;
                }
            }

			    if ( $key == 'id_usulan2') {
                foreach($value as $k=>$v) {
                    $id_usulan2[$k] = $v;
                }
            }

            if ( $key == 'check_usulan2_status') {
                foreach($value as $k=>$v) {
                    $check_usulan2_status[$k] = $v;
                }
            }

      			if ( $key == 'alasan_usulan2') {
                      foreach($value as $k=>$v) {
                          $alasan_usulan2[$k] = $v;
                      }
                  }
              }


        //print_r($id_usulan);
        //print_r($check_usulan_status);
        //exit;
        $query = array();
		$query2 = array();
		$query3 = array();
        foreach($id_usulan1 as $k=>$v) {
      			if ( !empty($check_usulan1_status[$k]) ) {
      				$status = $check_usulan1_status[$k];
      				if ( $check_usulan_jenis[$k] == 2 ) $status = 7; //selesai
      
      				$query[] = "UPDATE app_t_usulan 
                				set istatus = {$status},
                				tupdated = '".date('Y-m-d H:i:s')."',
                				cupdatedby = '".trim($this->session->username)."' 
                				where id = ".$v;
                				
                	$r_usulan = $this->getrow('', 'app_t_usulan', 'istatus, ijns, cnousul, iunorid', array('id'=>$v));
            			$current_status = $r_usulan->istatus;
            			$ijns = $r_usulan->ijns;
            			$cnousul = $r_usulan->cnousul;
            			$iunorid = $r_usulan->iunorid;
            			
            			$post = [
              	     'cnousul'=>$r_usulan->cnousul,
              	     'usulanid'=> $v
              	  ];
      
      
      				if ( $check_usulan_jenis[$k] == 2 )	{
      				  $query2[] = "update app_t_usulan_pegawai set istatus = 1, istatus2=1 
									where iusulanid = {$v} and istatus2 = 0";
					  
					  //update berdasarkan cnipold
					  $sql2 = "SELECT ckduker, cnipold, ijabid2 
							  from app_t_usulan_pegawai 
							  where iusulanid = {$v}";
					  foreach($this->db->query($sql2)->result() as $r) {
						  
						/*$query3[] = "UPDATE app_t_usulan_pegawai set isnonaktif=1
								where ckduker =  '{$r->ckduker}' 
								and iusulanid != '{$v}' 
								and cnip = '{$r->cnipold}'";*/
						$query3[] = "UPDATE app_t_usulan_pegawai set isnonaktif=1
								where ckduker =  '{$r->ckduker}' 
								and iusulanid != '{$v}' 
								and ijabid2 = '{$r->ijabid2}'";
						
						//echo '1 : '.$this->db->last_query();
						//exit;
					  }
      				} else {
      				  //send email
      				  $nextapproval = 3;
                //send email
                  $tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[$nextapproval]->url."'>disini</a>";
    			        $pesan = str_replace("__tautan__", $tautan, $this->session->sysparam->group_verifikator[$nextapproval]->msg);
    			        //echo 'a';
    			        $this->send_email($nextapproval, '', $pesan, $post, TRUE);
    			        
    			        //update status app_notification
              		$where = ['usulanid'=>$v, 'groupid'=>$this->session->sysparam->group_verifikator[($nextapproval-1)]->id];
              		$datas = ['isread'=>1, 'updated'=>date('Y-m-d H:i:s'), 'updatedby'=>trim($this->session->username)];
              		$this->db->where($where);
              		$this->db->update('app_notification', $datas);
        		
        		/*$sql = $this->db->set($datas)->get_compiled_update('app_notification');
            echo $sql;exit;*/
    			        //echo 'b';
    			        //exit;
    			        //
    			        //send_email ke requestor
              		$tos = [
              		  0=>(object)['unorid'=>$iunorid, 'email'=>$this->getrow('', 'priv_t_user', 'email', ['username'=>trim($iunorid)])->email]
              		];
              		//print_r($tos);
              		//exit;
                  $tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[99]->url."?q=".$cnousul."'>disini</a>";
                         
                  $tahap = $this->session->sysparam->status_usulan[$current_status+1];
                  $pesan = str_replace("__tautan__", $tautan, $this->session->sysparam->group_verifikator[99]->msg);
                  $pesan = str_replace("__tahap__", $tahap, $pesan);
              		$this->send_email(99, $tos, $pesan, $post);
                //send email
      				}
      			}
        }

		foreach($id_usulan2 as $k=>$v) {
			if ( !empty($check_usulan2_status[$k]) )  { 
				$query[] = "UPDATE app_t_usulan 
    					set istatus = ".$check_usulan2_status[$k].",
    					valasan = '".$alasan_usulan2[$k]."',
    					tupdated = '".date('Y-m-d H:i:s')."',
    					cupdatedby = '".trim($this->session->username)."'  
    					where id = ".$v;
    
    				if ( $check_usulan_jenis[$k] == 2 )	{
    				  	$query2[] = "update app_t_usulan_pegawai set istatus = 2, valasan='".$alasan_usulan2[$k]."', 
    							istatus2=2, valasan2='".$alasan_usulan2[$k]."', 
								itolak = itolak + 1  
    							where iusulanid = {$v}";
    				} else {
    				  
						$r_usulan = $this->getrow('', 'app_t_usulan', 'istatus, ijns, cnousul, iunorid', array('id'=>$v));
						$current_status = $r_usulan->istatus;
						$ijns = $r_usulan->ijns;
						$cnousul = $r_usulan->cnousul;
						$iunorid = $r_usulan->iunorid;
						
						$post = [
							'cnousul'=>$r_usulan->cnousul,
							'usulanid'=> $v
						];
    				  
						$tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[100]->url."?q=".$cnousul."'>disini</a>";
						
						$tahap = $this->session->sysparam->status_usulan[$current_status];
						$pesan = str_replace("__tautan__", $tautan, $this->session->sysparam->group_verifikator[100]->msg);
						$pesan = str_replace("__tahap__", $tahap, $pesan);
						$this->send_email(100, $tos, $pesan, $post);
              		
    				}
    		}
        }

        //print_r($query);
        //exit;
        $ok=0;
        try {
            foreach($query as $q) {
                $this->db->query($q);
                $ok++;
            }
        }catch(Exception $e) {
            die($e);
        }

        try {
            foreach($query2 as $q2) {
                $this->db->query($q2);
                $ok++;
            }
        }catch(Exception $e) {
            die($e);
        }
		
		try {
            foreach($query3 as $q3) {
                $this->db->query($q3);
                $ok++;
            }
        }catch(Exception $e) {
            die($e);
        }

        $data = array();
        if ( $ok > 0 ) {
            $data['status'] = true;
        } else $data['status'] = false;

        echo json_encode($data);
    }
    
		function send_email($next=0, $tos='', $pesan='', $post, $isnotif=FALSE) {
		  
		  $post = (object)$post;
  		if ($tos=='') {
  		  $groupid = $this->session->sysparam->group_verifikator[$next]->id;
  		  //echo $groupid;
    		$sql = "SELECT email, username from priv_t_user where igroupid like '%{$groupid}%'";
    		//echo $sql;
    		$tos = $this->db->query($sql)->result();
  		}
  		
  		if ($isnotif==TRUE) {
          $pesan = $this->session->sysparam->group_verifikator[$next]->desc;
          $tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[$next]->url."'>{$pesan}</a>";
          $notifs=[
                //'username'=>$t2->username,
                'url'=>base_url().$this->session->sysparam->group_verifikator[$next]->url,
                'usulanid'=>$post->usulanid,
                'groupid'=>$groupid,
                'msg' => $pesan,
                'created'=> date('Y-m-d H:i:s'),
                'createdby'=>trim($this->session->username)
          ];
          $this->db->insert('app_notification', $notifs);
		  /*print_r($this->session->sysparam->group_verifikator[$next]);
		  print_r($notifs);
          $sql = $this->db->set($notifs)->get_compiled_insert('app_notification');
          echo $sql;exit;*/
      }
      
  		//PHPMailer
  	  $mail = new PHPMailer(true);
  	  //print_r($mail);
  	  //exit;
  	  
  	  /*echo $this->session->sysparam->smtphost[0];
  	  echo $this->session->sysparam->smtpauth[0];
  	  echo $this->session->sysparam->smtpsecure[0];
  	  echo $this->session->sysparam->smtpuser[0];
  	  echo $this->session->sysparam->smtppasswd[0];
  	  echo $this->session->sysparam->smtpport[0];
  	  exit;*/
  	  
  	  /* Open the try/catch block. */
      try {
         /* SMTP parameters. */
         $mail->isSMTP();
         $mail->Host = $this->session->sysparam->smtphost[0];
         $mail->SMTPAuth = $this->session->sysparam->smtpauth[0];
         $mail->SMTPSecure = $this->session->sysparam->smtpsecure[0];
         $mail->Username = $this->session->sysparam->smtpuser[0];
         $mail->Password = $this->session->sysparam->smtppasswd[0];
         $mail->Port = $this->session->sysparam->smtpport[0];
     
         /* Set the mail sender. */
         $mail->setFrom($this->session->sysparam->smtpuser[0], 'POSTMASTER');
      
         /* Add a recipient. */
         foreach($tos as $t1=>$t2) {
           $mail->addAddress($t2->email, $t2->email);
         }
      
         /* Set the subject. */
         $mail->Subject = $this->session->sysparam->group_verifikator[$next]->subject;
      
         /* Set the mail message body. */
         $mail->isHTML(TRUE);
         
         if ($pesan == '' ) {
           $tautan = "<a href='".base_url().$this->session->sysparam->group_verifikator[$next]->url."?q=".$post."'>disini</a>";
           
           $pesan = str_replace("__tautan__", $tautan, $this->session->sysparam->group_verifikator[$next]->msg);
         }
         
         $mail->Body = $pesan;
         //if ($next==0) {
        //   print_r($mail);
        //   exit;
         //}
         /* Finally send the mail. */
         $mail->send();
         $status = true;
         // 'Email Terkirim';
      }
      catch (Exception $e)
      {
         /* PHPMailer exception. */
         $status = false;
         $pesan = $e->errorMessage();
      }
      catch (\Exception $e)
      {
         /* PHP exception (note the backslash to select the global namespace Exception class). */
         $status = false;
         $pesan = $e->getMessage();
      }
  	  
  	  $datas = [
  	       'status' => $status,
  	       'msg' => $pesan
  	     ];
  	     
  	  //return $datas;
  	  //print_r($datas);exit;
    }
}
